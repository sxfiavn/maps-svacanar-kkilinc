import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/FileLoader.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=577582ce"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/mason/Desktop/Brown/CS32/hw3-p1/mock-mlee168-mlo5/mock/src/components/FileLoader.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=577582ce"; const useEffect = __vite__cjsImport3_react["useEffect"];
import { mockDataMap } from "/src/mocked/mockedJson.ts";
export const FileLoader = ({
  filePath,
  onFileLoad
}) => {
  _s();
  const preprocessFilePath = (path) => {
    let processedPath = path.trim();
    if (processedPath === "") {
      console.error("Error: The file path is empty after trimming.");
      return null;
    }
    processedPath = processedPath.replace(/^["']|["']$/g, "");
    processedPath = processedPath.replace(/\/+/g, "/");
    processedPath = processedPath.replace(/\\/g, "/");
    processedPath = processedPath.replace(/\s+/g, " ");
    processedPath = processedPath.replace(/(\.\.\/)|(~\/)|(\.$)/g, "");
    const specialCharacters = /[!@#$%^&*()+{};':"|,.<>?]+/;
    if (specialCharacters.test(processedPath)) {
      console.error("Error: The file path contains special characters.");
      return null;
    }
    if (processedPath.includes("..")) {
      console.error("Error: The file path is trying to escape the root directory.");
      return null;
    }
    const validFileFormats = /.*\.(csv|json)$/;
    if (!validFileFormats.test(processedPath)) {
      console.error("Error: Invalid file format.");
      return null;
    }
    return processedPath;
  };
  const loadData = () => {
    const processedFilePath2 = preprocessFilePath(filePath);
    if (processedFilePath2) {
      const data = mockDataMap[processedFilePath2];
      if (data) {
        onFileLoad(data);
      } else {
        console.error("Error: File not found in mockDataMap.");
      }
    }
  };
  useEffect(() => {
    loadData();
  }, [filePath]);
  const processedFilePath = preprocessFilePath(filePath);
  return /* @__PURE__ */ jsxDEV("div", { children: processedFilePath ? /* @__PURE__ */ jsxDEV("p", { children: [
    "Processed File Path: ",
    processedFilePath
  ] }, void 0, true, {
    fileName: "C:/Users/mason/Desktop/Brown/CS32/hw3-p1/mock-mlee168-mlo5/mock/src/components/FileLoader.tsx",
    lineNumber: 72,
    columnNumber: 28
  }, this) : /* @__PURE__ */ jsxDEV("p", { children: "Error: Invalid File Path" }, void 0, false, {
    fileName: "C:/Users/mason/Desktop/Brown/CS32/hw3-p1/mock-mlee168-mlo5/mock/src/components/FileLoader.tsx",
    lineNumber: 72,
    columnNumber: 78
  }, this) }, void 0, false, {
    fileName: "C:/Users/mason/Desktop/Brown/CS32/hw3-p1/mock-mlee168-mlo5/mock/src/components/FileLoader.tsx",
    lineNumber: 71,
    columnNumber: 10
  }, this);
};
_s(FileLoader, "OD7bBpZva5O2jO+Puf00hKivP7c=");
_c = FileLoader;
export const AvailableFilesList = () => {
  if (!mockDataMap) {
    return /* @__PURE__ */ jsxDEV("div", { children: "Error: Data not available." }, void 0, false, {
      fileName: "C:/Users/mason/Desktop/Brown/CS32/hw3-p1/mock-mlee168-mlo5/mock/src/components/FileLoader.tsx",
      lineNumber: 83,
      columnNumber: 12
    }, this);
  }
  const availableFiles = Object.keys(mockDataMap);
  if (availableFiles.length === 0) {
    return /* @__PURE__ */ jsxDEV("div", { children: "No files available." }, void 0, false, {
      fileName: "C:/Users/mason/Desktop/Brown/CS32/hw3-p1/mock-mlee168-mlo5/mock/src/components/FileLoader.tsx",
      lineNumber: 89,
      columnNumber: 12
    }, this);
  }
  return /* @__PURE__ */ jsxDEV("ul", { children: availableFiles.map((filePath, index) => (
    // Check if filePath is not null or empty
    filePath ? /* @__PURE__ */ jsxDEV("li", { children: filePath }, index, false, {
      fileName: "C:/Users/mason/Desktop/Brown/CS32/hw3-p1/mock-mlee168-mlo5/mock/src/components/FileLoader.tsx",
      lineNumber: 94,
      columnNumber: 16
    }, this) : /* @__PURE__ */ jsxDEV("li", { children: "Unknown File" }, index, false, {
      fileName: "C:/Users/mason/Desktop/Brown/CS32/hw3-p1/mock-mlee168-mlo5/mock/src/components/FileLoader.tsx",
      lineNumber: 94,
      columnNumber: 50
    }, this)
  )) }, void 0, false, {
    fileName: "C:/Users/mason/Desktop/Brown/CS32/hw3-p1/mock-mlee168-mlo5/mock/src/components/FileLoader.tsx",
    lineNumber: 91,
    columnNumber: 10
  }, this);
};
_c2 = AvailableFilesList;
export const OnStartUp = () => {
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("h2", { children: "Welcome to our REPL" }, void 0, false, {
      fileName: "C:/Users/mason/Desktop/Brown/CS32/hw3-p1/mock-mlee168-mlo5/mock/src/components/FileLoader.tsx",
      lineNumber: 103,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("p", { children: "This REPL allows you to interact with data files, view their contents, search them, and change the display mode." }, void 0, false, {
      fileName: "C:/Users/mason/Desktop/Brown/CS32/hw3-p1/mock-mlee168-mlo5/mock/src/components/FileLoader.tsx",
      lineNumber: 104,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("h3", { children: "Available Files:" }, void 0, false, {
      fileName: "C:/Users/mason/Desktop/Brown/CS32/hw3-p1/mock-mlee168-mlo5/mock/src/components/FileLoader.tsx",
      lineNumber: 108,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(AvailableFilesList, {}, void 0, false, {
      fileName: "C:/Users/mason/Desktop/Brown/CS32/hw3-p1/mock-mlee168-mlo5/mock/src/components/FileLoader.tsx",
      lineNumber: 109,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("h3", { children: "Valid Commands:" }, void 0, false, {
      fileName: "C:/Users/mason/Desktop/Brown/CS32/hw3-p1/mock-mlee168-mlo5/mock/src/components/FileLoader.tsx",
      lineNumber: 110,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("ul", { children: [
      /* @__PURE__ */ jsxDEV("li", { children: [
        /* @__PURE__ */ jsxDEV("strong", { children: "load_file [filePath]" }, void 0, false, {
          fileName: "C:/Users/mason/Desktop/Brown/CS32/hw3-p1/mock-mlee168-mlo5/mock/src/components/FileLoader.tsx",
          lineNumber: 113,
          columnNumber: 11
        }, this),
        ": Load a CSV data from the specified file.",
        /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
          fileName: "C:/Users/mason/Desktop/Brown/CS32/hw3-p1/mock-mlee168-mlo5/mock/src/components/FileLoader.tsx",
          lineNumber: 115,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("em", { children: "Example:" }, void 0, false, {
          fileName: "C:/Users/mason/Desktop/Brown/CS32/hw3-p1/mock-mlee168-mlo5/mock/src/components/FileLoader.tsx",
          lineNumber: 116,
          columnNumber: 11
        }, this),
        " ",
        /* @__PURE__ */ jsxDEV("code", { children: "load_file /path/to/myfile.csv" }, void 0, false, {
          fileName: "C:/Users/mason/Desktop/Brown/CS32/hw3-p1/mock-mlee168-mlo5/mock/src/components/FileLoader.tsx",
          lineNumber: 116,
          columnNumber: 29
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/mason/Desktop/Brown/CS32/hw3-p1/mock-mlee168-mlo5/mock/src/components/FileLoader.tsx",
        lineNumber: 112,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("li", { children: [
        /* @__PURE__ */ jsxDEV("strong", { children: "view" }, void 0, false, {
          fileName: "C:/Users/mason/Desktop/Brown/CS32/hw3-p1/mock-mlee168-mlo5/mock/src/components/FileLoader.tsx",
          lineNumber: 119,
          columnNumber: 11
        }, this),
        ": Display the currently loaded CSV data.",
        /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
          fileName: "C:/Users/mason/Desktop/Brown/CS32/hw3-p1/mock-mlee168-mlo5/mock/src/components/FileLoader.tsx",
          lineNumber: 120,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("em", { children: "Example:" }, void 0, false, {
          fileName: "C:/Users/mason/Desktop/Brown/CS32/hw3-p1/mock-mlee168-mlo5/mock/src/components/FileLoader.tsx",
          lineNumber: 121,
          columnNumber: 11
        }, this),
        " ",
        /* @__PURE__ */ jsxDEV("code", { children: "view" }, void 0, false, {
          fileName: "C:/Users/mason/Desktop/Brown/CS32/hw3-p1/mock-mlee168-mlo5/mock/src/components/FileLoader.tsx",
          lineNumber: 121,
          columnNumber: 29
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/mason/Desktop/Brown/CS32/hw3-p1/mock-mlee168-mlo5/mock/src/components/FileLoader.tsx",
        lineNumber: 118,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("li", { children: [
        /* @__PURE__ */ jsxDEV("strong", { children: "search [column] [value]" }, void 0, false, {
          fileName: "C:/Users/mason/Desktop/Brown/CS32/hw3-p1/mock-mlee168-mlo5/mock/src/components/FileLoader.tsx",
          lineNumber: 124,
          columnNumber: 11
        }, this),
        ": Search for a specific value in the specified column of the loaded data.",
        /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
          fileName: "C:/Users/mason/Desktop/Brown/CS32/hw3-p1/mock-mlee168-mlo5/mock/src/components/FileLoader.tsx",
          lineNumber: 126,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("em", { children: "Example:" }, void 0, false, {
          fileName: "C:/Users/mason/Desktop/Brown/CS32/hw3-p1/mock-mlee168-mlo5/mock/src/components/FileLoader.tsx",
          lineNumber: 127,
          columnNumber: 11
        }, this),
        " ",
        /* @__PURE__ */ jsxDEV("code", { children: "search name John" }, void 0, false, {
          fileName: "C:/Users/mason/Desktop/Brown/CS32/hw3-p1/mock-mlee168-mlo5/mock/src/components/FileLoader.tsx",
          lineNumber: 127,
          columnNumber: 29
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/mason/Desktop/Brown/CS32/hw3-p1/mock-mlee168-mlo5/mock/src/components/FileLoader.tsx",
        lineNumber: 123,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("li", { children: [
        /* @__PURE__ */ jsxDEV("strong", { children: "mode [verbose/brief]" }, void 0, false, {
          fileName: "C:/Users/mason/Desktop/Brown/CS32/hw3-p1/mock-mlee168-mlo5/mock/src/components/FileLoader.tsx",
          lineNumber: 130,
          columnNumber: 11
        }, this),
        ": Change the display mode of the REPL.",
        /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
          fileName: "C:/Users/mason/Desktop/Brown/CS32/hw3-p1/mock-mlee168-mlo5/mock/src/components/FileLoader.tsx",
          lineNumber: 132,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("em", { children: "Example:" }, void 0, false, {
          fileName: "C:/Users/mason/Desktop/Brown/CS32/hw3-p1/mock-mlee168-mlo5/mock/src/components/FileLoader.tsx",
          lineNumber: 133,
          columnNumber: 11
        }, this),
        " ",
        /* @__PURE__ */ jsxDEV("code", { children: "mode verbose" }, void 0, false, {
          fileName: "C:/Users/mason/Desktop/Brown/CS32/hw3-p1/mock-mlee168-mlo5/mock/src/components/FileLoader.tsx",
          lineNumber: 133,
          columnNumber: 29
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/mason/Desktop/Brown/CS32/hw3-p1/mock-mlee168-mlo5/mock/src/components/FileLoader.tsx",
        lineNumber: 129,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/mason/Desktop/Brown/CS32/hw3-p1/mock-mlee168-mlo5/mock/src/components/FileLoader.tsx",
      lineNumber: 111,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/mason/Desktop/Brown/CS32/hw3-p1/mock-mlee168-mlo5/mock/src/components/FileLoader.tsx",
    lineNumber: 102,
    columnNumber: 10
  }, this);
};
_c3 = OnStartUp;
var _c, _c2, _c3;
$RefreshReg$(_c, "FileLoader");
$RefreshReg$(_c2, "AvailableFilesList");
$RefreshReg$(_c3, "OnStartUp");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/mason/Desktop/Brown/CS32/hw3-p1/mock-mlee168-mlo5/mock/src/components/FileLoader.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBK0VROzs7Ozs7Ozs7Ozs7Ozs7OztBQS9FUixTQUFnQkEsaUJBQWlCO0FBQ2pDLFNBQVNDLG1CQUFtQjtBQUdyQixhQUFNQyxhQUF3Q0EsQ0FBQztBQUFBLEVBQ3BEQztBQUFBQSxFQUNBQztBQUNGLE1BQU07QUFBQUMsS0FBQTtBQUNKLFFBQU1DLHFCQUFxQkEsQ0FBQ0MsU0FBZ0M7QUFFMUQsUUFBSUMsZ0JBQWdCRCxLQUFLRSxLQUFLO0FBRzlCLFFBQUlELGtCQUFrQixJQUFJO0FBQ3hCRSxjQUFRQyxNQUFNLCtDQUErQztBQUM3RCxhQUFPO0FBQUEsSUFDVDtBQUdBSCxvQkFBZ0JBLGNBQWNJLFFBQVEsZ0JBQWdCLEVBQUU7QUFHeERKLG9CQUFnQkEsY0FBY0ksUUFBUSxRQUFRLEdBQUc7QUFHakRKLG9CQUFnQkEsY0FBY0ksUUFBUSxPQUFPLEdBQUc7QUFHaERKLG9CQUFnQkEsY0FBY0ksUUFBUSxRQUFRLEdBQUc7QUFHakRKLG9CQUFnQkEsY0FBY0ksUUFBUSx5QkFBeUIsRUFBRTtBQUdqRSxVQUFNQyxvQkFBb0I7QUFDMUIsUUFBSUEsa0JBQWtCQyxLQUFLTixhQUFhLEdBQUc7QUFDekNFLGNBQVFDLE1BQU0sbURBQW1EO0FBQ2pFLGFBQU87QUFBQSxJQUNUO0FBR0EsUUFBSUgsY0FBY08sU0FBUyxJQUFJLEdBQUc7QUFDaENMLGNBQVFDLE1BQ04sOERBQ0Y7QUFDQSxhQUFPO0FBQUEsSUFDVDtBQUdBLFVBQU1LLG1CQUFtQjtBQUN6QixRQUFJLENBQUNBLGlCQUFpQkYsS0FBS04sYUFBYSxHQUFHO0FBQ3pDRSxjQUFRQyxNQUFNLDZCQUE2QjtBQUMzQyxhQUFPO0FBQUEsSUFDVDtBQUVBLFdBQU9IO0FBQUFBLEVBQ1Q7QUFFQSxRQUFNUyxXQUFXQSxNQUFNO0FBQ3JCLFVBQU1DLHFCQUFvQlosbUJBQW1CSCxRQUFRO0FBQ3JELFFBQUllLG9CQUFtQjtBQUNyQixZQUFNQyxPQUFPbEIsWUFBWWlCLGtCQUFpQjtBQUMxQyxVQUFJQyxNQUFNO0FBQ1JmLG1CQUFXZSxJQUFJO0FBQUEsTUFDakIsT0FBTztBQUNMVCxnQkFBUUMsTUFBTSx1Q0FBdUM7QUFBQSxNQUN2RDtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBRUFYLFlBQVUsTUFBTTtBQUNkaUIsYUFBUztBQUFBLEVBQ1gsR0FBRyxDQUFDZCxRQUFRLENBQUM7QUFFYixRQUFNZSxvQkFBb0JaLG1CQUFtQkgsUUFBUTtBQUVyRCxTQUNFLHVCQUFDLFNBQ0VlLDhCQUNDLHVCQUFDLE9BQUU7QUFBQTtBQUFBLElBQXNCQTtBQUFBQSxPQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQTJDLElBRTNDLHVCQUFDLE9BQUUsd0NBQUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUEyQixLQUovQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBTUE7QUFFSjtBQUNBYixHQWxGYUgsWUFBcUM7QUFBQWtCLEtBQXJDbEI7QUFxRk4sYUFBTW1CLHFCQUErQkEsTUFBTTtBQUVoRCxNQUFJLENBQUNwQixhQUFhO0FBQ2hCLFdBQU8sdUJBQUMsU0FBSSwwQ0FBTDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQStCO0FBQUEsRUFDeEM7QUFFQSxRQUFNcUIsaUJBQWlCQyxPQUFPQyxLQUFLdkIsV0FBVztBQUc5QyxNQUFJcUIsZUFBZUcsV0FBVyxHQUFHO0FBQy9CLFdBQU8sdUJBQUMsU0FBSSxtQ0FBTDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXdCO0FBQUEsRUFDakM7QUFFQSxTQUNFLHVCQUFDLFFBQ0VILHlCQUFlSSxJQUFJLENBQUN2QixVQUFVd0I7QUFBQUE7QUFBQUEsSUFFN0J4QixXQUNFLHVCQUFDLFFBQWdCQSxzQkFBUndCLE9BQVQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUEwQixJQUUxQix1QkFBQyxRQUFlLDRCQUFQQSxPQUFUO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBNEI7QUFBQSxHQUVoQyxLQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FTQTtBQUVKO0FBQ0FDLE1BMUJhUDtBQTZCTixhQUFNUSxZQUFzQkEsTUFBTTtBQUN2QyxTQUNFLHVCQUFDLFNBQ0M7QUFBQSwyQkFBQyxRQUFHLG1DQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBdUI7QUFBQSxJQUN2Qix1QkFBQyxPQUFFLGdJQUFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHQTtBQUFBLElBQ0EsdUJBQUMsUUFBRyxnQ0FBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQW9CO0FBQUEsSUFDcEIsdUJBQUMsd0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFtQjtBQUFBLElBQ25CLHVCQUFDLFFBQUcsK0JBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFtQjtBQUFBLElBQ25CLHVCQUFDLFFBQ0M7QUFBQSw2QkFBQyxRQUNDO0FBQUEsK0JBQUMsWUFBTyxvQ0FBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTRCO0FBQUEsUUFBUztBQUFBLFFBRXJDLHVCQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFHO0FBQUEsUUFDSCx1QkFBQyxRQUFHLHdCQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBWTtBQUFBLFFBQUs7QUFBQSxRQUFDLHVCQUFDLFVBQUssNkNBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFtQztBQUFBLFdBSnZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLQTtBQUFBLE1BQ0EsdUJBQUMsUUFDQztBQUFBLCtCQUFDLFlBQU8sb0JBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFZO0FBQUEsUUFBUztBQUFBLFFBQ3JCLHVCQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFHO0FBQUEsUUFDSCx1QkFBQyxRQUFHLHdCQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBWTtBQUFBLFFBQUs7QUFBQSxRQUFDLHVCQUFDLFVBQUssb0JBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFVO0FBQUEsV0FIOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUlBO0FBQUEsTUFDQSx1QkFBQyxRQUNDO0FBQUEsK0JBQUMsWUFBTyx1Q0FBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQStCO0FBQUEsUUFBUztBQUFBLFFBRXhDLHVCQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFHO0FBQUEsUUFDSCx1QkFBQyxRQUFHLHdCQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBWTtBQUFBLFFBQUs7QUFBQSxRQUFDLHVCQUFDLFVBQUssZ0NBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFzQjtBQUFBLFdBSjFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLQTtBQUFBLE1BQ0EsdUJBQUMsUUFDQztBQUFBLCtCQUFDLFlBQU8sb0NBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE0QjtBQUFBLFFBQVM7QUFBQSxRQUVyQyx1QkFBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBRztBQUFBLFFBQ0gsdUJBQUMsUUFBRyx3QkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQVk7QUFBQSxRQUFLO0FBQUEsUUFBQyx1QkFBQyxVQUFLLDRCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa0I7QUFBQSxXQUp0QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS0E7QUFBQSxTQXZCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBd0JBO0FBQUEsT0FqQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWtDQTtBQUVKO0FBQUVDLE1BdENXRDtBQUFtQixJQUFBVCxJQUFBUSxLQUFBRTtBQUFBQyxhQUFBWCxJQUFBO0FBQUFXLGFBQUFILEtBQUE7QUFBQUcsYUFBQUQsS0FBQSIsIm5hbWVzIjpbInVzZUVmZmVjdCIsIm1vY2tEYXRhTWFwIiwiRmlsZUxvYWRlciIsImZpbGVQYXRoIiwib25GaWxlTG9hZCIsIl9zIiwicHJlcHJvY2Vzc0ZpbGVQYXRoIiwicGF0aCIsInByb2Nlc3NlZFBhdGgiLCJ0cmltIiwiY29uc29sZSIsImVycm9yIiwicmVwbGFjZSIsInNwZWNpYWxDaGFyYWN0ZXJzIiwidGVzdCIsImluY2x1ZGVzIiwidmFsaWRGaWxlRm9ybWF0cyIsImxvYWREYXRhIiwicHJvY2Vzc2VkRmlsZVBhdGgiLCJkYXRhIiwiX2MiLCJBdmFpbGFibGVGaWxlc0xpc3QiLCJhdmFpbGFibGVGaWxlcyIsIk9iamVjdCIsImtleXMiLCJsZW5ndGgiLCJtYXAiLCJpbmRleCIsIl9jMiIsIk9uU3RhcnRVcCIsIl9jMyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkZpbGVMb2FkZXIudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VFZmZlY3QgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgbW9ja0RhdGFNYXAgfSBmcm9tIFwiLi4vbW9ja2VkL21vY2tlZEpzb25cIjtcclxuaW1wb3J0IHsgRmlsZUxvYWRlclByb3BzIH0gZnJvbSBcIi4vdHlwZXNcIjtcclxuXHJcbmV4cG9ydCBjb25zdCBGaWxlTG9hZGVyOiBSZWFjdC5GQzxGaWxlTG9hZGVyUHJvcHM+ID0gKHtcclxuICBmaWxlUGF0aCxcclxuICBvbkZpbGVMb2FkLFxyXG59KSA9PiB7XHJcbiAgY29uc3QgcHJlcHJvY2Vzc0ZpbGVQYXRoID0gKHBhdGg6IHN0cmluZyk6IHN0cmluZyB8IG51bGwgPT4ge1xyXG4gICAgLy8gU3RlcCAxOiBUcmltIGxlYWRpbmcgYW5kIHRyYWlsaW5nIHdoaXRlIHNwYWNlc1xyXG4gICAgbGV0IHByb2Nlc3NlZFBhdGggPSBwYXRoLnRyaW0oKTtcclxuXHJcbiAgICAvLyBTdGVwIDI6IFZhbGlkYXRlIGFnYWluc3QgYW4gZW1wdHkgc3RyaW5nXHJcbiAgICBpZiAocHJvY2Vzc2VkUGF0aCA9PT0gXCJcIikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3I6IFRoZSBmaWxlIHBhdGggaXMgZW1wdHkgYWZ0ZXIgdHJpbW1pbmcuXCIpO1xyXG4gICAgICByZXR1cm4gbnVsbDtcclxuICAgIH1cclxuXHJcbiAgICAvLyBTdGVwIDM6IFJlbW92ZSBsZWFkaW5nIGFuZCB0cmFpbGluZyBxdW90ZXMgaWYgcHJlc2VudFxyXG4gICAgcHJvY2Vzc2VkUGF0aCA9IHByb2Nlc3NlZFBhdGgucmVwbGFjZSgvXltcIiddfFtcIiddJC9nLCBcIlwiKTtcclxuXHJcbiAgICAvLyBTdGVwIDQ6IFJlcGxhY2UgbXVsdGlwbGUgc2xhc2hlcyB3aXRoIGEgc2luZ2xlIHNsYXNoXHJcbiAgICBwcm9jZXNzZWRQYXRoID0gcHJvY2Vzc2VkUGF0aC5yZXBsYWNlKC9cXC8rL2csIFwiL1wiKTtcclxuXHJcbiAgICAvLyBTdGVwIDU6IENvbnZlcnQgYmFja3NsYXNoZXMgdG8gZm9yd2FyZCBzbGFzaGVzXHJcbiAgICBwcm9jZXNzZWRQYXRoID0gcHJvY2Vzc2VkUGF0aC5yZXBsYWNlKC9cXFxcL2csIFwiL1wiKTtcclxuXHJcbiAgICAvLyBTdGVwIDY6IFJlcGxhY2UgbXVsdGlwbGUgc3BhY2VzIHdpdGggYSBzaW5nbGUgc3BhY2VcclxuICAgIHByb2Nlc3NlZFBhdGggPSBwcm9jZXNzZWRQYXRoLnJlcGxhY2UoL1xccysvZywgXCIgXCIpO1xyXG5cclxuICAgIC8vIFN0ZXAgNzogUmVtb3ZlIGFueSBoYXJtZnVsIHNlcXVlbmNlcyBvciBjaGFyYWN0ZXJzXHJcbiAgICBwcm9jZXNzZWRQYXRoID0gcHJvY2Vzc2VkUGF0aC5yZXBsYWNlKC8oXFwuXFwuXFwvKXwoflxcLyl8KFxcLiQpL2csIFwiXCIpO1xyXG5cclxuICAgIC8vIFN0ZXAgODogQ2hlY2sgZm9yIHNwZWNpYWwgY2hhcmFjdGVycyB0aGF0IG1pZ2h0IGJlIHVuc2FmZVxyXG4gICAgY29uc3Qgc3BlY2lhbENoYXJhY3RlcnMgPSAvWyFAIyQlXiYqKCkre307JzpcInwsLjw+P10rLztcclxuICAgIGlmIChzcGVjaWFsQ2hhcmFjdGVycy50ZXN0KHByb2Nlc3NlZFBhdGgpKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvcjogVGhlIGZpbGUgcGF0aCBjb250YWlucyBzcGVjaWFsIGNoYXJhY3RlcnMuXCIpO1xyXG4gICAgICByZXR1cm4gbnVsbDtcclxuICAgIH1cclxuXHJcbiAgICAvLyBTdGVwIDk6IENoZWNrIGZvciBkaXJlY3RvcnkgY2xpbWJpbmcgYXR0ZW1wdHNcclxuICAgIGlmIChwcm9jZXNzZWRQYXRoLmluY2x1ZGVzKFwiLi5cIikpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcclxuICAgICAgICBcIkVycm9yOiBUaGUgZmlsZSBwYXRoIGlzIHRyeWluZyB0byBlc2NhcGUgdGhlIHJvb3QgZGlyZWN0b3J5LlwiXHJcbiAgICAgICk7XHJcbiAgICAgIHJldHVybiBudWxsO1xyXG4gICAgfVxyXG5cclxuICAgIC8vIFN0ZXAgMTA6IENoZWNrIGZvciB2YWxpZCBmaWxlIGZvcm1hdHNcclxuICAgIGNvbnN0IHZhbGlkRmlsZUZvcm1hdHMgPSAvLipcXC4oY3N2fGpzb24pJC87XHJcbiAgICBpZiAoIXZhbGlkRmlsZUZvcm1hdHMudGVzdChwcm9jZXNzZWRQYXRoKSkge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3I6IEludmFsaWQgZmlsZSBmb3JtYXQuXCIpO1xyXG4gICAgICByZXR1cm4gbnVsbDtcclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4gcHJvY2Vzc2VkUGF0aDtcclxuICB9O1xyXG5cclxuICBjb25zdCBsb2FkRGF0YSA9ICgpID0+IHtcclxuICAgIGNvbnN0IHByb2Nlc3NlZEZpbGVQYXRoID0gcHJlcHJvY2Vzc0ZpbGVQYXRoKGZpbGVQYXRoKTtcclxuICAgIGlmIChwcm9jZXNzZWRGaWxlUGF0aCkge1xyXG4gICAgICBjb25zdCBkYXRhID0gbW9ja0RhdGFNYXBbcHJvY2Vzc2VkRmlsZVBhdGhdO1xyXG4gICAgICBpZiAoZGF0YSkge1xyXG4gICAgICAgIG9uRmlsZUxvYWQoZGF0YSk7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yOiBGaWxlIG5vdCBmb3VuZCBpbiBtb2NrRGF0YU1hcC5cIik7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9O1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgbG9hZERhdGEoKTtcclxuICB9LCBbZmlsZVBhdGhdKTtcclxuXHJcbiAgY29uc3QgcHJvY2Vzc2VkRmlsZVBhdGggPSBwcmVwcm9jZXNzRmlsZVBhdGgoZmlsZVBhdGgpO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdj5cclxuICAgICAge3Byb2Nlc3NlZEZpbGVQYXRoID8gKFxyXG4gICAgICAgIDxwPlByb2Nlc3NlZCBGaWxlIFBhdGg6IHtwcm9jZXNzZWRGaWxlUGF0aH08L3A+XHJcbiAgICAgICkgOiAoXHJcbiAgICAgICAgPHA+RXJyb3I6IEludmFsaWQgRmlsZSBQYXRoPC9wPlxyXG4gICAgICApfVxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufTtcclxuLyoqXHJcbiAqIEF2YWlsYWJsZUZpbGVzTGlzdCBjb21wb25lbnQgZm9yIGRpc3BsYXlpbmcgYXZhaWxhYmxlIGZpbGVzLlxyXG4gKi9cclxuZXhwb3J0IGNvbnN0IEF2YWlsYWJsZUZpbGVzTGlzdDogUmVhY3QuRkMgPSAoKSA9PiB7XHJcbiAgLy8gQ2hlY2sgaWYgbW9ja0RhdGFNYXAgaXMgbm90IG51bGwgb3IgdW5kZWZpbmVkXHJcbiAgaWYgKCFtb2NrRGF0YU1hcCkge1xyXG4gICAgcmV0dXJuIDxkaXY+RXJyb3I6IERhdGEgbm90IGF2YWlsYWJsZS48L2Rpdj47XHJcbiAgfVxyXG5cclxuICBjb25zdCBhdmFpbGFibGVGaWxlcyA9IE9iamVjdC5rZXlzKG1vY2tEYXRhTWFwKTtcclxuXHJcbiAgLy8gQ2hlY2sgaWYgYXZhaWxhYmxlRmlsZXMgYXJyYXkgaXMgZW1wdHlcclxuICBpZiAoYXZhaWxhYmxlRmlsZXMubGVuZ3RoID09PSAwKSB7XHJcbiAgICByZXR1cm4gPGRpdj5ObyBmaWxlcyBhdmFpbGFibGUuPC9kaXY+O1xyXG4gIH1cclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDx1bD5cclxuICAgICAge2F2YWlsYWJsZUZpbGVzLm1hcCgoZmlsZVBhdGgsIGluZGV4KSA9PlxyXG4gICAgICAgIC8vIENoZWNrIGlmIGZpbGVQYXRoIGlzIG5vdCBudWxsIG9yIGVtcHR5XHJcbiAgICAgICAgZmlsZVBhdGggPyAoXHJcbiAgICAgICAgICA8bGkga2V5PXtpbmRleH0+e2ZpbGVQYXRofTwvbGk+XHJcbiAgICAgICAgKSA6IChcclxuICAgICAgICAgIDxsaSBrZXk9e2luZGV4fT5Vbmtub3duIEZpbGU8L2xpPlxyXG4gICAgICAgIClcclxuICAgICAgKX1cclxuICAgIDwvdWw+XHJcbiAgKTtcclxufTtcclxuLyoqXHJcbiAqIE9uU3RhcnRVcCBjb21wb25lbnQgZm9yIGRpc3BsYXlpbmcgdGhlIHdlbGNvbWUgbWVzc2FnZSBhbmQgYXZhaWxhYmxlIGNvbW1hbmRzLlxyXG4gKi9cclxuZXhwb3J0IGNvbnN0IE9uU3RhcnRVcDogUmVhY3QuRkMgPSAoKSA9PiB7XHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXY+XHJcbiAgICAgIDxoMj5XZWxjb21lIHRvIG91ciBSRVBMPC9oMj5cclxuICAgICAgPHA+XHJcbiAgICAgICAgVGhpcyBSRVBMIGFsbG93cyB5b3UgdG8gaW50ZXJhY3Qgd2l0aCBkYXRhIGZpbGVzLCB2aWV3IHRoZWlyIGNvbnRlbnRzLFxyXG4gICAgICAgIHNlYXJjaCB0aGVtLCBhbmQgY2hhbmdlIHRoZSBkaXNwbGF5IG1vZGUuXHJcbiAgICAgIDwvcD5cclxuICAgICAgPGgzPkF2YWlsYWJsZSBGaWxlczo8L2gzPlxyXG4gICAgICA8QXZhaWxhYmxlRmlsZXNMaXN0IC8+XHJcbiAgICAgIDxoMz5WYWxpZCBDb21tYW5kczo8L2gzPlxyXG4gICAgICA8dWw+XHJcbiAgICAgICAgPGxpPlxyXG4gICAgICAgICAgPHN0cm9uZz5sb2FkX2ZpbGUgW2ZpbGVQYXRoXTwvc3Ryb25nPjogTG9hZCBhIENTViBkYXRhIGZyb20gdGhlXHJcbiAgICAgICAgICBzcGVjaWZpZWQgZmlsZS5cclxuICAgICAgICAgIDxiciAvPlxyXG4gICAgICAgICAgPGVtPkV4YW1wbGU6PC9lbT4gPGNvZGU+bG9hZF9maWxlIC9wYXRoL3RvL215ZmlsZS5jc3Y8L2NvZGU+XHJcbiAgICAgICAgPC9saT5cclxuICAgICAgICA8bGk+XHJcbiAgICAgICAgICA8c3Ryb25nPnZpZXc8L3N0cm9uZz46IERpc3BsYXkgdGhlIGN1cnJlbnRseSBsb2FkZWQgQ1NWIGRhdGEuXHJcbiAgICAgICAgICA8YnIgLz5cclxuICAgICAgICAgIDxlbT5FeGFtcGxlOjwvZW0+IDxjb2RlPnZpZXc8L2NvZGU+XHJcbiAgICAgICAgPC9saT5cclxuICAgICAgICA8bGk+XHJcbiAgICAgICAgICA8c3Ryb25nPnNlYXJjaCBbY29sdW1uXSBbdmFsdWVdPC9zdHJvbmc+OiBTZWFyY2ggZm9yIGEgc3BlY2lmaWMgdmFsdWVcclxuICAgICAgICAgIGluIHRoZSBzcGVjaWZpZWQgY29sdW1uIG9mIHRoZSBsb2FkZWQgZGF0YS5cclxuICAgICAgICAgIDxiciAvPlxyXG4gICAgICAgICAgPGVtPkV4YW1wbGU6PC9lbT4gPGNvZGU+c2VhcmNoIG5hbWUgSm9objwvY29kZT5cclxuICAgICAgICA8L2xpPlxyXG4gICAgICAgIDxsaT5cclxuICAgICAgICAgIDxzdHJvbmc+bW9kZSBbdmVyYm9zZS9icmllZl08L3N0cm9uZz46IENoYW5nZSB0aGUgZGlzcGxheSBtb2RlIG9mIHRoZVxyXG4gICAgICAgICAgUkVQTC5cclxuICAgICAgICAgIDxiciAvPlxyXG4gICAgICAgICAgPGVtPkV4YW1wbGU6PC9lbT4gPGNvZGU+bW9kZSB2ZXJib3NlPC9jb2RlPlxyXG4gICAgICAgIDwvbGk+XHJcbiAgICAgIDwvdWw+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59O1xyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL21hc29uL0Rlc2t0b3AvQnJvd24vQ1MzMi9odzMtcDEvbW9jay1tbGVlMTY4LW1sbzUvbW9jay9zcmMvY29tcG9uZW50cy9GaWxlTG9hZGVyLnRzeCJ9