import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/styles/App.css");import { updateStyle as __vite__updateStyle, removeStyle as __vite__removeStyle } from "/@vite/client"
const __vite__id = "C:/Users/mason/Desktop/Brown/CS32/hw3-p1/mock-mlee168-mlo5/mock/src/styles/App.css"
const __vite__css = ".App {\r\n  text-align: center;\r\n}\r\n\r\n.App-header {\r\n  background-color: #282c34;\r\n  min-height: 8vh;\r\n  display: flex;\r\n  flex-direction: column;\r\n  align-items: center;\r\n  justify-content: center;\r\n  font-size: calc(1px + 2vmin);\r\n  color: white;\r\n}"
__vite__updateStyle(__vite__id, __vite__css)
import.meta.hot.accept()
export default __vite__css
import.meta.hot.prune(() => __vite__removeStyle(__vite__id))