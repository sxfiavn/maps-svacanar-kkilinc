import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/REPLHistory.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=577582ce"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/mason/Desktop/Brown/CS32/hw3-p1/mock-mlee168-mlo5/mock/src/components/REPLHistory.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import "/src/styles/main.css";
export function REPLHistory(props) {
  return /* @__PURE__ */ jsxDEV("div", { className: "repl-history", children: props.history.map((item, index) => /* @__PURE__ */ jsxDEV("div", { children: props.mode === "verbose" ? /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("div", { children: [
      "Command: ",
      item.command
    ] }, void 0, true, {
      fileName: "C:/Users/mason/Desktop/Brown/CS32/hw3-p1/mock-mlee168-mlo5/mock/src/components/REPLHistory.tsx",
      lineNumber: 15,
      columnNumber: 15
    }, this),
    /* @__PURE__ */ jsxDEV("div", { children: [
      "Output: ",
      item.result
    ] }, void 0, true, {
      fileName: "C:/Users/mason/Desktop/Brown/CS32/hw3-p1/mock-mlee168-mlo5/mock/src/components/REPLHistory.tsx",
      lineNumber: 16,
      columnNumber: 15
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/mason/Desktop/Brown/CS32/hw3-p1/mock-mlee168-mlo5/mock/src/components/REPLHistory.tsx",
    lineNumber: 14,
    columnNumber: 39
  }, this) : /* @__PURE__ */ jsxDEV("div", { children: [
    "Result: ",
    item.result
  ] }, void 0, true, {
    fileName: "C:/Users/mason/Desktop/Brown/CS32/hw3-p1/mock-mlee168-mlo5/mock/src/components/REPLHistory.tsx",
    lineNumber: 17,
    columnNumber: 22
  }, this) }, index, false, {
    fileName: "C:/Users/mason/Desktop/Brown/CS32/hw3-p1/mock-mlee168-mlo5/mock/src/components/REPLHistory.tsx",
    lineNumber: 13,
    columnNumber: 43
  }, this)) }, void 0, false, {
    fileName: "C:/Users/mason/Desktop/Brown/CS32/hw3-p1/mock-mlee168-mlo5/mock/src/components/REPLHistory.tsx",
    lineNumber: 12,
    columnNumber: 10
  }, this);
}
_c = REPLHistory;
var _c;
$RefreshReg$(_c, "REPLHistory");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/mason/Desktop/Brown/CS32/hw3-p1/mock-mlee168-mlo5/mock/src/components/REPLHistory.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa0JjO0FBbEJkLDJCQUFvQjtBQUFpQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ3JDLE9BQU87QUFVQSxnQkFBU0EsWUFBWUMsT0FBeUI7QUFDbkQsU0FDRSx1QkFBQyxTQUFJLFdBQVUsZ0JBQ1pBLGdCQUFNQyxRQUFRQyxJQUFJLENBQUNDLE1BQU1DLFVBQ3hCLHVCQUFDLFNBQ0VKLGdCQUFNSyxTQUFTLFlBQ2QsdUJBQUMsU0FDQztBQUFBLDJCQUFDLFNBQUk7QUFBQTtBQUFBLE1BQVVGLEtBQUtHO0FBQUFBLFNBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBNEI7QUFBQSxJQUM1Qix1QkFBQyxTQUFJO0FBQUE7QUFBQSxNQUFTSCxLQUFLSTtBQUFBQSxTQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTBCO0FBQUEsT0FGNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUdBLElBRUEsdUJBQUMsU0FBSTtBQUFBO0FBQUEsSUFBU0osS0FBS0k7QUFBQUEsT0FBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUEwQixLQVBwQkgsT0FBVjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBU0EsQ0FDRCxLQVpIO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FhQTtBQUVKO0FBQUNJLEtBakJlVDtBQUFXLElBQUFTO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJSRVBMSGlzdG9yeSIsInByb3BzIiwiaGlzdG9yeSIsIm1hcCIsIml0ZW0iLCJpbmRleCIsIm1vZGUiLCJjb21tYW5kIiwicmVzdWx0IiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJSRVBMSGlzdG9yeS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSW5wdXRPYmplY3QgfSBmcm9tIFwiLi90eXBlc1wiO1xyXG5pbXBvcnQgXCIuLi9zdHlsZXMvbWFpbi5jc3NcIjtcclxuXHJcbmludGVyZmFjZSBSRVBMSGlzdG9yeVByb3BzIHtcclxuICBoaXN0b3J5OiBJbnB1dE9iamVjdFtdO1xyXG4gIG1vZGU6IHN0cmluZztcclxufVxyXG4vKipcclxuICogUkVQTEhpc3RvcnkgY29tcG9uZW50IGRpc3BsYXlzIHRoZSBoaXN0b3J5IG9mIGNvbW1hbmRzIGFuZCB0aGVpciByZXN1bHRzIGluIHRoZSBSRVBMLlxyXG4gKiBAcGFyYW0gcHJvcHMgLSBUaGUgY29tcG9uZW50J3MgcHJvcGVydGllcywgaW5jbHVkaW5nIHRoZSBjb21tYW5kIGhpc3RvcnkgYW5kIGRpc3BsYXkgbW9kZS5cclxuICovXHJcbmV4cG9ydCBmdW5jdGlvbiBSRVBMSGlzdG9yeShwcm9wczogUkVQTEhpc3RvcnlQcm9wcykgeyAgXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwicmVwbC1oaXN0b3J5XCI+XHJcbiAgICAgIHtwcm9wcy5oaXN0b3J5Lm1hcCgoaXRlbSwgaW5kZXgpID0+IChcclxuICAgICAgICA8ZGl2IGtleT17aW5kZXh9PlxyXG4gICAgICAgICAge3Byb3BzLm1vZGUgPT09IFwidmVyYm9zZVwiID8gKFxyXG4gICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXY+Q29tbWFuZDoge2l0ZW0uY29tbWFuZH08L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2Pk91dHB1dDoge2l0ZW0ucmVzdWx0fTwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgIDxkaXY+UmVzdWx0OiB7aXRlbS5yZXN1bHR9PC9kaXY+XHJcbiAgICAgICAgICApfVxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICApKX1cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn1cclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9tYXNvbi9EZXNrdG9wL0Jyb3duL0NTMzIvaHczLXAxL21vY2stbWxlZTE2OC1tbG81L21vY2svc3JjL2NvbXBvbmVudHMvUkVQTEhpc3RvcnkudHN4In0=