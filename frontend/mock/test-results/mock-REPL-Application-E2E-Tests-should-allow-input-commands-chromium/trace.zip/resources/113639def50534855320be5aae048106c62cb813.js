import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ControlledInput.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=577582ce"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/mason/Desktop/Brown/CS32/hw3-p1/mock-mlee168-mlo5/mock/src/components/ControlledInput.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import "/src/styles/main.css";
export function ControlledInput({
  value,
  setValue,
  ariaLabel
}) {
  return /* @__PURE__ */ jsxDEV("input", { type: "text", className: "repl-command-box", value, placeholder: "Enter command here!", onChange: (ev) => setValue(ev.target.value), "aria-label": ariaLabel }, void 0, false, {
    fileName: "C:/Users/mason/Desktop/Brown/CS32/hw3-p1/mock-mlee168-mlo5/mock/src/components/ControlledInput.tsx",
    lineNumber: 21,
    columnNumber: 10
  }, this);
}
_c = ControlledInput;
var _c;
$RefreshReg$(_c, "ControlledInput");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/mason/Desktop/Brown/CS32/hw3-p1/mock-mlee168-mlo5/mock/src/components/ControlledInput.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaUJNO0FBakJOLE9BQU8sb0JBQW9CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBZWxCLGdCQUFTQSxnQkFBZ0I7QUFBQSxFQUFDQztBQUFBQSxFQUFPQztBQUFBQSxFQUFVQztBQUErQixHQUFHO0FBQ2xGLFNBQ0UsdUJBQUMsV0FBTSxNQUFLLFFBQU8sV0FBVSxvQkFDdkIsT0FDQSxhQUFZLHVCQUNaLFVBQVdDLFFBQU9GLFNBQVNFLEdBQUdDLE9BQU9KLEtBQUssR0FDMUMsY0FBWUUsYUFKbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUtBO0FBRUo7QUFBQ0csS0FUZU47QUFBZSxJQUFBTTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiQ29udHJvbGxlZElucHV0IiwidmFsdWUiLCJzZXRWYWx1ZSIsImFyaWFMYWJlbCIsImV2IiwidGFyZ2V0IiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJDb250cm9sbGVkSW5wdXQudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCAnLi4vc3R5bGVzL21haW4uY3NzJztcclxuaW1wb3J0IHsgRGlzcGF0Y2gsIFNldFN0YXRlQWN0aW9uIH0gZnJvbSAncmVhY3QnO1xyXG5cclxuLy8gUmVtZW1iZXIgdGhhdCBwYXJhbWV0ZXIgbmFtZXMgZG9uJ3QgbmVjZXNzYXJpbHkgbmVlZCB0byBvdmVybGFwO1xyXG4vLyBJIGNvdWxkIHVzZSBkaWZmZXJlbnQgdmFyaWFibGUgbmFtZXMgaW4gdGhlIGFjdHVhbCBmdW5jdGlvbi5cclxuaW50ZXJmYWNlIENvbnRyb2xsZWRJbnB1dFByb3BzIHtcclxuICAgIHZhbHVlOiBzdHJpbmcsIFxyXG4gICAgLy8gVGhpcyB0eXBlIGNvbWVzIGZyb20gUmVhY3QrVHlwZVNjcmlwdC4gVlNDb2RlIGNhbiBzdWdnZXN0IHRoZXNlLlxyXG4gICAgLy8gICBDb25jcmV0ZWx5LCB0aGlzIG1lYW5zIFwiYSBmdW5jdGlvbiB0aGF0IHNldHMgYSBzdGF0ZSBjb250YWluaW5nIGEgc3RyaW5nXCJcclxuICAgIHNldFZhbHVlOiBEaXNwYXRjaDxTZXRTdGF0ZUFjdGlvbjxzdHJpbmc+PixcclxuICAgIGFyaWFMYWJlbDogc3RyaW5nIFxyXG4gIH1cclxuICBcclxuICAvLyBJbnB1dCBib3hlcyBjb250YWluIHN0YXRlLiBXZSB3YW50IHRvIG1ha2Ugc3VyZSBSZWFjdCBpcyBtYW5hZ2luZyB0aGF0IHN0YXRlLFxyXG4gIC8vICAgc28gd2UgaGF2ZSBhIHNwZWNpYWwgY29tcG9uZW50IHRoYXQgd3JhcHMgdGhlIGlucHV0IGJveC5cclxuICBleHBvcnQgZnVuY3Rpb24gQ29udHJvbGxlZElucHV0KHt2YWx1ZSwgc2V0VmFsdWUsIGFyaWFMYWJlbH06IENvbnRyb2xsZWRJbnB1dFByb3BzKSB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICA8aW5wdXQgdHlwZT1cInRleHRcIiBjbGFzc05hbWU9XCJyZXBsLWNvbW1hbmQtYm94XCJcclxuICAgICAgICAgICAgdmFsdWU9e3ZhbHVlfSBcclxuICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBjb21tYW5kIGhlcmUhXCJcclxuICAgICAgICAgICAgb25DaGFuZ2U9eyhldikgPT4gc2V0VmFsdWUoZXYudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgYXJpYS1sYWJlbD17YXJpYUxhYmVsfT5cclxuICAgICAgPC9pbnB1dD5cclxuICAgICk7XHJcbiAgfSJdLCJmaWxlIjoiQzovVXNlcnMvbWFzb24vRGVza3RvcC9Ccm93bi9DUzMyL2h3My1wMS9tb2NrLW1sZWUxNjgtbWxvNS9tb2NrL3NyYy9jb21wb25lbnRzL0NvbnRyb2xsZWRJbnB1dC50c3gifQ==