import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/REPLInput.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=577582ce"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/mason/Desktop/Brown/CS32/hw3-p1/mock-mlee168-mlo5/mock/src/components/REPLInput.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=577582ce"; const useState = __vite__cjsImport3_react["useState"];
import { ControlledInput } from "/src/components/ControlledInput.tsx";
import { FileLoader } from "/src/components/FileLoader.tsx";
import ViewCSV from "/src/components/ViewCSV.tsx";
import SearchCSV from "/src/components/SearchCSV.tsx";
import { OnStartUp } from "/src/components/FileLoader.tsx";
import { fileToSearch } from "/src/mocked/mockedJson.ts";
export function REPLInput(props) {
  _s();
  const [commandString, setCommandString] = useState("");
  const [loadFile, setLoadFile] = useState(null);
  const [loaded, getLoaded] = useState("");
  const handleFileLoad = (data) => {
    props.onDataLoad(data);
    setLoadFile(null);
  };
  const handleSubmit = () => {
    const commandParts = commandString.split(" ");
    const command = commandParts[0];
    const parameters = commandParts.slice(1);
    let result = "";
    if (command === "load_file") {
      const filePath = parameters[0];
      if (filePath == "path/to/dataset1.csv" || filePath == "path/to/dataset2.csv" || filePath == "path/to/dataset3.csv" || filePath == "path/to/dataset4.csv") {
        setLoadFile(filePath);
        getLoaded(filePath);
        result = `Loaded CSV data from file: ${filePath}`;
      } else {
        result = "Not a valid file path.";
      }
    } else if (command === "view") {
      if (!props.loadedData) {
        result = "No data loaded. Please use load_file first.";
      } else {
        result = /* @__PURE__ */ jsxDEV(ViewCSV, { loadedData: props.loadedData, hasHeader: true }, void 0, false, {
          fileName: "C:/Users/mason/Desktop/Brown/CS32/hw3-p1/mock-mlee168-mlo5/mock/src/components/REPLInput.tsx",
          lineNumber: 50,
          columnNumber: 18
        }, this);
      }
    } else if (command === "search") {
      if (!props.loadedData) {
        result = "No data loaded. Please use load_file before searching.";
      } else {
        const [column, value] = parameters;
        const searchMap = fileToSearch[loaded];
        if (searchMap) {
          const searchKey = `search ${column.toLowerCase()} ${value.toLowerCase()}`;
          const searchResult = searchMap[searchKey];
          if (searchResult) {
            result = /* @__PURE__ */ jsxDEV(ViewCSV, { loadedData: searchResult, hasHeader: true }, void 0, false, {
              fileName: "C:/Users/mason/Desktop/Brown/CS32/hw3-p1/mock-mlee168-mlo5/mock/src/components/REPLInput.tsx",
              lineNumber: 66,
              columnNumber: 22
            }, this);
          } else {
            result = "No matching results found.";
          }
        } else {
          result = "No matching results found.";
        }
      }
    } else if (command === "mode") {
      const modeValue = parameters[0];
      const validModes = ["verbose", "brief"];
      if (validModes.includes(modeValue)) {
        props.onModeChange(modeValue);
        result = `Changed mode to '${modeValue}'`;
      } else {
        result = `${modeValue} is not a valid mode`;
      }
    } else if (command === "help") {
      result = /* @__PURE__ */ jsxDEV(OnStartUp, {}, void 0, false, {
        fileName: "C:/Users/mason/Desktop/Brown/CS32/hw3-p1/mock-mlee168-mlo5/mock/src/components/REPLInput.tsx",
        lineNumber: 84,
        columnNumber: 16
      }, this);
    } else if (command === "search") {
      if (!props.loadedData) {
        result = "No data loaded. Please use load_file before searching.";
      } else {
        result = /* @__PURE__ */ jsxDEV(SearchCSV, { loadedData: props.loadedData }, void 0, false, {
          fileName: "C:/Users/mason/Desktop/Brown/CS32/hw3-p1/mock-mlee168-mlo5/mock/src/components/REPLInput.tsx",
          lineNumber: 89,
          columnNumber: 18
        }, this);
      }
    } else {
      result = "Unknown command";
    }
    const newCommand = {
      command: commandString,
      result
    };
    props.onCommandSubmit(newCommand);
    setCommandString("");
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "repl-input", children: [
    loadFile && /* @__PURE__ */ jsxDEV(FileLoader, { filePath: loadFile, onFileLoad: handleFileLoad }, void 0, false, {
      fileName: "C:/Users/mason/Desktop/Brown/CS32/hw3-p1/mock-mlee168-mlo5/mock/src/components/REPLInput.tsx",
      lineNumber: 102,
      columnNumber: 20
    }, this),
    /* @__PURE__ */ jsxDEV("fieldset", { children: [
      /* @__PURE__ */ jsxDEV("legend", { children: "Enter a command:" }, void 0, false, {
        fileName: "C:/Users/mason/Desktop/Brown/CS32/hw3-p1/mock-mlee168-mlo5/mock/src/components/REPLInput.tsx",
        lineNumber: 104,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(ControlledInput, { value: commandString, setValue: setCommandString, ariaLabel: "Command input" }, void 0, false, {
        fileName: "C:/Users/mason/Desktop/Brown/CS32/hw3-p1/mock-mlee168-mlo5/mock/src/components/REPLInput.tsx",
        lineNumber: 105,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/mason/Desktop/Brown/CS32/hw3-p1/mock-mlee168-mlo5/mock/src/components/REPLInput.tsx",
      lineNumber: 103,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("button", { onClick: handleSubmit, children: "Submit" }, void 0, false, {
      fileName: "C:/Users/mason/Desktop/Brown/CS32/hw3-p1/mock-mlee168-mlo5/mock/src/components/REPLInput.tsx",
      lineNumber: 107,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/mason/Desktop/Brown/CS32/hw3-p1/mock-mlee168-mlo5/mock/src/components/REPLInput.tsx",
    lineNumber: 101,
    columnNumber: 10
  }, this);
}
_s(REPLInput, "yMiOLVcbXyGzCLHSwdwO9+VbO3o=");
_c = REPLInput;
var _c;
$RefreshReg$(_c, "REPLInput");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/mason/Desktop/Brown/CS32/hw3-p1/mock-mlee168-mlo5/mock/src/components/REPLInput.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBdURpQjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUF2RGpCLFNBQWdCQSxnQkFBZ0I7QUFFaEMsU0FBU0MsdUJBQXVCO0FBQ2hDLFNBQVNDLGtCQUFrQjtBQUMzQixPQUFPQyxhQUFhO0FBRXBCLE9BQU9DLGVBQWU7QUFDdEIsU0FBNkJDLGlCQUFpQjtBQUM5QyxTQUFTQyxvQkFBb0I7QUFhdEIsZ0JBQVNDLFVBQVVDLE9BQXVCO0FBQUFDLEtBQUE7QUFDL0MsUUFBTSxDQUFDQyxlQUFlQyxnQkFBZ0IsSUFBSVgsU0FBaUIsRUFBRTtBQUM3RCxRQUFNLENBQUNZLFVBQVVDLFdBQVcsSUFBSWIsU0FBd0IsSUFBSTtBQUM1RCxRQUFNLENBQUNjLFFBQVFDLFNBQVMsSUFBSWYsU0FBaUIsRUFBRTtBQUUvQyxRQUFNZ0IsaUJBQWlCQSxDQUFDQyxTQUFxQjtBQUMzQ1QsVUFBTVUsV0FBV0QsSUFBSTtBQUNyQkosZ0JBQVksSUFBSTtBQUFBLEVBQ2xCO0FBRUEsUUFBTU0sZUFBZUEsTUFBTTtBQUN6QixVQUFNQyxlQUFlVixjQUFjVyxNQUFNLEdBQUc7QUFDNUMsVUFBTUMsVUFBVUYsYUFBYSxDQUFDO0FBQzlCLFVBQU1HLGFBQWFILGFBQWFJLE1BQU0sQ0FBQztBQUN2QyxRQUFJQyxTQUErQjtBQUVuQyxRQUFJSCxZQUFZLGFBQWE7QUFDM0IsWUFBTUksV0FBV0gsV0FBVyxDQUFDO0FBQzdCLFVBQ0VHLFlBQVksMEJBQ1pBLFlBQVksMEJBQ1pBLFlBQVksMEJBQ1pBLFlBQVksd0JBQ1o7QUFDQWIsb0JBQVlhLFFBQVE7QUFDcEJYLGtCQUFVVyxRQUFRO0FBQ2xCRCxpQkFBVSw4QkFBNkJDLFFBQVM7QUFBQSxNQUNsRCxPQUFPO0FBQ0xELGlCQUFTO0FBQUEsTUFDWDtBQUFBLElBQ0YsV0FBV0gsWUFBWSxRQUFRO0FBQzdCLFVBQUksQ0FBQ2QsTUFBTW1CLFlBQVk7QUFDckJGLGlCQUFTO0FBQUEsTUFDWCxPQUFPO0FBQ0xBLGlCQUFTLHVCQUFDLFdBQVEsWUFBWWpCLE1BQU1tQixZQUFZLFdBQVcsUUFBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF1RDtBQUFBLE1BRWxFO0FBQUEsSUFDRixXQUFXTCxZQUFZLFVBQVU7QUFDL0IsVUFBSSxDQUFDZCxNQUFNbUIsWUFBWTtBQUNyQkYsaUJBQVM7QUFBQSxNQUNYLE9BQU87QUFDTCxjQUFNLENBQUNHLFFBQVFDLEtBQUssSUFBSU47QUFFeEIsY0FBTU8sWUFBWXhCLGFBQWFRLE1BQU07QUFDckMsWUFBSWdCLFdBQVc7QUFFYixnQkFBTUMsWUFBYSxVQUFTSCxPQUFPSSxZQUFZLENBQUUsSUFBR0gsTUFBTUcsWUFBWSxDQUFFO0FBQ3hFLGdCQUFNQyxlQUFlSCxVQUFVQyxTQUFTO0FBQ3hDLGNBQUlFLGNBQWM7QUFFaEJSLHFCQUFTLHVCQUFDLFdBQVEsWUFBWVEsY0FBYyxXQUFXLFFBQTlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW1EO0FBQUEsVUFDOUQsT0FBTztBQUNMUixxQkFBUztBQUFBLFVBQ1g7QUFBQSxRQUNGLE9BQU87QUFDTEEsbUJBQVM7QUFBQSxRQUNYO0FBQUEsTUFDRjtBQUFBLElBQ0YsV0FBV0gsWUFBWSxRQUFRO0FBQzdCLFlBQU1ZLFlBQVlYLFdBQVcsQ0FBQztBQUM5QixZQUFNWSxhQUFhLENBQUMsV0FBVyxPQUFPO0FBRXRDLFVBQUlBLFdBQVdDLFNBQVNGLFNBQVMsR0FBRztBQUNsQzFCLGNBQU02QixhQUFhSCxTQUFTO0FBQzVCVCxpQkFBVSxvQkFBbUJTLFNBQVU7QUFBQSxNQUN6QyxPQUFPO0FBQ0xULGlCQUFVLEdBQUVTLFNBQVU7QUFBQSxNQUN4QjtBQUFBLElBQ0YsV0FBV1osWUFBWSxRQUFRO0FBQzdCRyxlQUFTLHVCQUFDLGVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFVO0FBQUEsSUFDckIsV0FBV0gsWUFBWSxVQUFVO0FBQy9CLFVBQUksQ0FBQ2QsTUFBTW1CLFlBQVk7QUFDckJGLGlCQUFTO0FBQUEsTUFDWCxPQUFPO0FBQ0xBLGlCQUFTLHVCQUFDLGFBQVUsWUFBWWpCLE1BQU1tQixjQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXdDO0FBQUEsTUFDbkQ7QUFBQSxJQUNGLE9BQU87QUFDTEYsZUFBUztBQUFBLElBQ1g7QUFFQSxVQUFNYSxhQUEwQjtBQUFBLE1BQzlCaEIsU0FBU1o7QUFBQUEsTUFDVGU7QUFBQUEsSUFDRjtBQUVBakIsVUFBTStCLGdCQUFnQkQsVUFBVTtBQUNoQzNCLHFCQUFpQixFQUFFO0FBQUEsRUFDckI7QUFFQSxTQUNFLHVCQUFDLFNBQUksV0FBVSxjQUNaQztBQUFBQSxnQkFDQyx1QkFBQyxjQUFXLFVBQVVBLFVBQVUsWUFBWUksa0JBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBMkQ7QUFBQSxJQUU3RCx1QkFBQyxjQUNDO0FBQUEsNkJBQUMsWUFBTyxnQ0FBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXdCO0FBQUEsTUFDeEIsdUJBQUMsbUJBQ0MsT0FBT04sZUFDUCxVQUFVQyxrQkFDVixXQUFVLG1CQUhaO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHMkI7QUFBQSxTQUw3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBT0E7QUFBQSxJQUNBLHVCQUFDLFlBQU8sU0FBU1EsY0FBYyxzQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFxQztBQUFBLE9BWnZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FhQTtBQUVKO0FBQUNWLEdBekdlRixXQUFTO0FBQUFpQyxLQUFUakM7QUFBUyxJQUFBaUM7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwiQ29udHJvbGxlZElucHV0IiwiRmlsZUxvYWRlciIsIlZpZXdDU1YiLCJTZWFyY2hDU1YiLCJPblN0YXJ0VXAiLCJmaWxlVG9TZWFyY2giLCJSRVBMSW5wdXQiLCJwcm9wcyIsIl9zIiwiY29tbWFuZFN0cmluZyIsInNldENvbW1hbmRTdHJpbmciLCJsb2FkRmlsZSIsInNldExvYWRGaWxlIiwibG9hZGVkIiwiZ2V0TG9hZGVkIiwiaGFuZGxlRmlsZUxvYWQiLCJkYXRhIiwib25EYXRhTG9hZCIsImhhbmRsZVN1Ym1pdCIsImNvbW1hbmRQYXJ0cyIsInNwbGl0IiwiY29tbWFuZCIsInBhcmFtZXRlcnMiLCJzbGljZSIsInJlc3VsdCIsImZpbGVQYXRoIiwibG9hZGVkRGF0YSIsImNvbHVtbiIsInZhbHVlIiwic2VhcmNoTWFwIiwic2VhcmNoS2V5IiwidG9Mb3dlckNhc2UiLCJzZWFyY2hSZXN1bHQiLCJtb2RlVmFsdWUiLCJ2YWxpZE1vZGVzIiwiaW5jbHVkZXMiLCJvbk1vZGVDaGFuZ2UiLCJuZXdDb21tYW5kIiwib25Db21tYW5kU3VibWl0IiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJSRVBMSW5wdXQudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5cclxuaW1wb3J0IHsgQ29udHJvbGxlZElucHV0IH0gZnJvbSBcIi4vQ29udHJvbGxlZElucHV0XCI7XHJcbmltcG9ydCB7IEZpbGVMb2FkZXIgfSBmcm9tIFwiLi9GaWxlTG9hZGVyXCI7XHJcbmltcG9ydCBWaWV3Q1NWIGZyb20gXCIuL1ZpZXdDU1ZcIjtcclxuaW1wb3J0IHsgSW5wdXRPYmplY3QgfSBmcm9tIFwiLi90eXBlc1wiO1xyXG5pbXBvcnQgU2VhcmNoQ1NWIGZyb20gXCIuL1NlYXJjaENTVlwiO1xyXG5pbXBvcnQgeyBBdmFpbGFibGVGaWxlc0xpc3QsIE9uU3RhcnRVcCB9IGZyb20gXCIuL0ZpbGVMb2FkZXJcIjtcclxuaW1wb3J0IHsgZmlsZVRvU2VhcmNoIH0gZnJvbSBcIi4uL21vY2tlZC9tb2NrZWRKc29uXCI7XHJcblxyXG5pbnRlcmZhY2UgUkVQTElucHV0UHJvcHMge1xyXG4gIG9uTW9kZUNoYW5nZTogKG5ld01vZGU6IHN0cmluZykgPT4gdm9pZDtcclxuICBvbkNvbW1hbmRTdWJtaXQ6IChjb21tYW5kOiBJbnB1dE9iamVjdCkgPT4gdm9pZDtcclxuICBvbkRhdGFMb2FkOiAoZGF0YTogc3RyaW5nW11bXSkgPT4gdm9pZDtcclxuICBsb2FkZWREYXRhOiBzdHJpbmdbXVtdIHwgbnVsbDsgLy8gdG8gZGV0ZXJtaW5lIGlmIGRhdGEgaXMgYWxyZWFkeSBsb2FkZWRcclxufVxyXG4vKipcclxuICogUkVQTElucHV0IGNvbXBvbmVudCBhbGxvd3MgdXNlcnMgdG8gZW50ZXIgY29tbWFuZHMsIGhhbmRsZXMgY29tbWFuZCBleGVjdXRpb24sXHJcbiAqIGFuZCBtYW5hZ2VzIGlucHV0L291dHB1dCBmb3IgdGhlIFJFUEwuXHJcbiAqIEBwYXJhbSBwcm9wcyAtIFRoZSBjb21wb25lbnQncyBwcm9wZXJ0aWVzLCBpbmNsdWRpbmcgaGFuZGxlcnMgZm9yIG1vZGUgY2hhbmdlLCBjb21tYW5kIHN1Ym1pc3Npb24sIGRhdGEgbG9hZGluZywgYW5kIGxvYWRlZCBkYXRhIHN0YXR1cy5cclxuICovXHJcbmV4cG9ydCBmdW5jdGlvbiBSRVBMSW5wdXQocHJvcHM6IFJFUExJbnB1dFByb3BzKSB7XHJcbiAgY29uc3QgW2NvbW1hbmRTdHJpbmcsIHNldENvbW1hbmRTdHJpbmddID0gdXNlU3RhdGU8c3RyaW5nPihcIlwiKTtcclxuICBjb25zdCBbbG9hZEZpbGUsIHNldExvYWRGaWxlXSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpO1xyXG4gIGNvbnN0IFtsb2FkZWQsIGdldExvYWRlZF0gPSB1c2VTdGF0ZTxzdHJpbmc+KFwiXCIpO1xyXG5cclxuICBjb25zdCBoYW5kbGVGaWxlTG9hZCA9IChkYXRhOiBzdHJpbmdbXVtdKSA9PiB7XHJcbiAgICBwcm9wcy5vbkRhdGFMb2FkKGRhdGEpO1xyXG4gICAgc2V0TG9hZEZpbGUobnVsbCk7IC8vIFJlc2V0IHRvIHByZXZlbnQgcmUtbG9hZGluZ1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVN1Ym1pdCA9ICgpID0+IHtcclxuICAgIGNvbnN0IGNvbW1hbmRQYXJ0cyA9IGNvbW1hbmRTdHJpbmcuc3BsaXQoXCIgXCIpO1xyXG4gICAgY29uc3QgY29tbWFuZCA9IGNvbW1hbmRQYXJ0c1swXTtcclxuICAgIGNvbnN0IHBhcmFtZXRlcnMgPSBjb21tYW5kUGFydHMuc2xpY2UoMSk7XHJcbiAgICBsZXQgcmVzdWx0OiBzdHJpbmcgfCBKU1guRWxlbWVudCA9IFwiXCI7IC8vVXBkYXRlIHRoZSByZXN1bHQgdmFyaWFibGUgdHlwZSBpbiBSRVBMSW5wdXRcclxuXHJcbiAgICBpZiAoY29tbWFuZCA9PT0gXCJsb2FkX2ZpbGVcIikge1xyXG4gICAgICBjb25zdCBmaWxlUGF0aCA9IHBhcmFtZXRlcnNbMF07XHJcbiAgICAgIGlmIChcclxuICAgICAgICBmaWxlUGF0aCA9PSBcInBhdGgvdG8vZGF0YXNldDEuY3N2XCIgfHxcclxuICAgICAgICBmaWxlUGF0aCA9PSBcInBhdGgvdG8vZGF0YXNldDIuY3N2XCIgfHxcclxuICAgICAgICBmaWxlUGF0aCA9PSBcInBhdGgvdG8vZGF0YXNldDMuY3N2XCIgfHxcclxuICAgICAgICBmaWxlUGF0aCA9PSBcInBhdGgvdG8vZGF0YXNldDQuY3N2XCJcclxuICAgICAgKSB7XHJcbiAgICAgICAgc2V0TG9hZEZpbGUoZmlsZVBhdGgpO1xyXG4gICAgICAgIGdldExvYWRlZChmaWxlUGF0aCk7XHJcbiAgICAgICAgcmVzdWx0ID0gYExvYWRlZCBDU1YgZGF0YSBmcm9tIGZpbGU6ICR7ZmlsZVBhdGh9YDsgLy8gQ29uY2F0ZW5hdGUgZmlsZVBhdGggd2l0aCB0aGUgcmVzdWx0XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgcmVzdWx0ID0gXCJOb3QgYSB2YWxpZCBmaWxlIHBhdGguXCI7XHJcbiAgICAgIH1cclxuICAgIH0gZWxzZSBpZiAoY29tbWFuZCA9PT0gXCJ2aWV3XCIpIHtcclxuICAgICAgaWYgKCFwcm9wcy5sb2FkZWREYXRhKSB7XHJcbiAgICAgICAgcmVzdWx0ID0gXCJObyBkYXRhIGxvYWRlZC4gUGxlYXNlIHVzZSBsb2FkX2ZpbGUgZmlyc3QuXCI7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgcmVzdWx0ID0gPFZpZXdDU1YgbG9hZGVkRGF0YT17cHJvcHMubG9hZGVkRGF0YX0gaGFzSGVhZGVyPXt0cnVlfSAvPjtcclxuICAgICAgICAvL3Jlc3VsdCA9IFwiRGlzcGxheWVkIENTViBkYXRhXCI7XHJcbiAgICAgIH1cclxuICAgIH0gZWxzZSBpZiAoY29tbWFuZCA9PT0gXCJzZWFyY2hcIikge1xyXG4gICAgICBpZiAoIXByb3BzLmxvYWRlZERhdGEpIHtcclxuICAgICAgICByZXN1bHQgPSBcIk5vIGRhdGEgbG9hZGVkLiBQbGVhc2UgdXNlIGxvYWRfZmlsZSBiZWZvcmUgc2VhcmNoaW5nLlwiO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIGNvbnN0IFtjb2x1bW4sIHZhbHVlXSA9IHBhcmFtZXRlcnM7XHJcbiAgICAgICAgLy9maW5kIHdoaWNoIG1hcCB0byB1c2VcclxuICAgICAgICBjb25zdCBzZWFyY2hNYXAgPSBmaWxlVG9TZWFyY2hbbG9hZGVkXTtcclxuICAgICAgICBpZiAoc2VhcmNoTWFwKSB7XHJcbiAgICAgICAgICAvL2ZpbmQgb3V0cHV0XHJcbiAgICAgICAgICBjb25zdCBzZWFyY2hLZXkgPSBgc2VhcmNoICR7Y29sdW1uLnRvTG93ZXJDYXNlKCl9ICR7dmFsdWUudG9Mb3dlckNhc2UoKX1gO1xyXG4gICAgICAgICAgY29uc3Qgc2VhcmNoUmVzdWx0ID0gc2VhcmNoTWFwW3NlYXJjaEtleV07XHJcbiAgICAgICAgICBpZiAoc2VhcmNoUmVzdWx0KSB7XHJcbiAgICAgICAgICAgIC8vcmVzdWx0ID0gc2VhcmNoUmVzdWx0LnRvU3RyaW5nKCk7XHJcbiAgICAgICAgICAgIHJlc3VsdCA9IDxWaWV3Q1NWIGxvYWRlZERhdGE9e3NlYXJjaFJlc3VsdH0gaGFzSGVhZGVyPXt0cnVlfSAvPjtcclxuICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHJlc3VsdCA9IFwiTm8gbWF0Y2hpbmcgcmVzdWx0cyBmb3VuZC5cIjtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgcmVzdWx0ID0gXCJObyBtYXRjaGluZyByZXN1bHRzIGZvdW5kLlwiO1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgfSBlbHNlIGlmIChjb21tYW5kID09PSBcIm1vZGVcIikge1xyXG4gICAgICBjb25zdCBtb2RlVmFsdWUgPSBwYXJhbWV0ZXJzWzBdO1xyXG4gICAgICBjb25zdCB2YWxpZE1vZGVzID0gW1widmVyYm9zZVwiLCBcImJyaWVmXCJdO1xyXG5cclxuICAgICAgaWYgKHZhbGlkTW9kZXMuaW5jbHVkZXMobW9kZVZhbHVlKSkge1xyXG4gICAgICAgIHByb3BzLm9uTW9kZUNoYW5nZShtb2RlVmFsdWUpO1xyXG4gICAgICAgIHJlc3VsdCA9IGBDaGFuZ2VkIG1vZGUgdG8gJyR7bW9kZVZhbHVlfSdgO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIHJlc3VsdCA9IGAke21vZGVWYWx1ZX0gaXMgbm90IGEgdmFsaWQgbW9kZWA7XHJcbiAgICAgIH1cclxuICAgIH0gZWxzZSBpZiAoY29tbWFuZCA9PT0gXCJoZWxwXCIpIHtcclxuICAgICAgcmVzdWx0ID0gPE9uU3RhcnRVcCAvPjtcclxuICAgIH0gZWxzZSBpZiAoY29tbWFuZCA9PT0gXCJzZWFyY2hcIikge1xyXG4gICAgICBpZiAoIXByb3BzLmxvYWRlZERhdGEpIHtcclxuICAgICAgICByZXN1bHQgPSBcIk5vIGRhdGEgbG9hZGVkLiBQbGVhc2UgdXNlIGxvYWRfZmlsZSBiZWZvcmUgc2VhcmNoaW5nLlwiO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIHJlc3VsdCA9IDxTZWFyY2hDU1YgbG9hZGVkRGF0YT17cHJvcHMubG9hZGVkRGF0YX0gLz47XHJcbiAgICAgIH1cclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHJlc3VsdCA9IFwiVW5rbm93biBjb21tYW5kXCI7XHJcbiAgICB9XHJcblxyXG4gICAgY29uc3QgbmV3Q29tbWFuZDogSW5wdXRPYmplY3QgPSB7XHJcbiAgICAgIGNvbW1hbmQ6IGNvbW1hbmRTdHJpbmcsXHJcbiAgICAgIHJlc3VsdDogcmVzdWx0LFxyXG4gICAgfTtcclxuXHJcbiAgICBwcm9wcy5vbkNvbW1hbmRTdWJtaXQobmV3Q29tbWFuZCk7XHJcbiAgICBzZXRDb21tYW5kU3RyaW5nKFwiXCIpO1xyXG4gIH07XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInJlcGwtaW5wdXRcIj5cclxuICAgICAge2xvYWRGaWxlICYmIChcclxuICAgICAgICA8RmlsZUxvYWRlciBmaWxlUGF0aD17bG9hZEZpbGV9IG9uRmlsZUxvYWQ9e2hhbmRsZUZpbGVMb2FkfSAvPlxyXG4gICAgICApfVxyXG4gICAgICA8ZmllbGRzZXQ+XHJcbiAgICAgICAgPGxlZ2VuZD5FbnRlciBhIGNvbW1hbmQ6PC9sZWdlbmQ+XHJcbiAgICAgICAgPENvbnRyb2xsZWRJbnB1dFxyXG4gICAgICAgICAgdmFsdWU9e2NvbW1hbmRTdHJpbmd9XHJcbiAgICAgICAgICBzZXRWYWx1ZT17c2V0Q29tbWFuZFN0cmluZ31cclxuICAgICAgICAgIGFyaWFMYWJlbD1cIkNvbW1hbmQgaW5wdXRcIlxyXG4gICAgICAgIC8+XHJcbiAgICAgIDwvZmllbGRzZXQ+XHJcbiAgICAgIDxidXR0b24gb25DbGljaz17aGFuZGxlU3VibWl0fT5TdWJtaXQ8L2J1dHRvbj5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn1cclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9tYXNvbi9EZXNrdG9wL0Jyb3duL0NTMzIvaHczLXAxL21vY2stbWxlZTE2OC1tbG81L21vY2svc3JjL2NvbXBvbmVudHMvUkVQTElucHV0LnRzeCJ9