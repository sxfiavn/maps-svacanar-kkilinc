import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ViewCSV.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=577582ce"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/mason/Desktop/Brown/CS32/hw3-p1/mock-mlee168-mlo5/mock/src/components/ViewCSV.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
const ViewCSV = ({
  loadedData,
  hasHeader
}) => {
  if (!loadedData)
    return null;
  const startIndex = hasHeader ? 1 : 0;
  return /* @__PURE__ */ jsxDEV("table", { children: [
    hasHeader && /* @__PURE__ */ jsxDEV("thead", { children: /* @__PURE__ */ jsxDEV("tr", { children: loadedData[0].map((header, index) => /* @__PURE__ */ jsxDEV("th", { children: header }, index, false, {
      fileName: "C:/Users/mason/Desktop/Brown/CS32/hw3-p1/mock-mlee168-mlo5/mock/src/components/ViewCSV.tsx",
      lineNumber: 17,
      columnNumber: 51
    }, this)) }, void 0, false, {
      fileName: "C:/Users/mason/Desktop/Brown/CS32/hw3-p1/mock-mlee168-mlo5/mock/src/components/ViewCSV.tsx",
      lineNumber: 16,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "C:/Users/mason/Desktop/Brown/CS32/hw3-p1/mock-mlee168-mlo5/mock/src/components/ViewCSV.tsx",
      lineNumber: 15,
      columnNumber: 21
    }, this),
    /* @__PURE__ */ jsxDEV("tbody", { children: loadedData.slice(startIndex).map((row, rowIndex) => /* @__PURE__ */ jsxDEV("tr", { children: row.map((cell, cellIndex) => /* @__PURE__ */ jsxDEV("td", { children: cell }, cellIndex, false, {
      fileName: "C:/Users/mason/Desktop/Brown/CS32/hw3-p1/mock-mlee168-mlo5/mock/src/components/ViewCSV.tsx",
      lineNumber: 22,
      columnNumber: 43
    }, this)) }, rowIndex, false, {
      fileName: "C:/Users/mason/Desktop/Brown/CS32/hw3-p1/mock-mlee168-mlo5/mock/src/components/ViewCSV.tsx",
      lineNumber: 21,
      columnNumber: 62
    }, this)) }, void 0, false, {
      fileName: "C:/Users/mason/Desktop/Brown/CS32/hw3-p1/mock-mlee168-mlo5/mock/src/components/ViewCSV.tsx",
      lineNumber: 20,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/mason/Desktop/Brown/CS32/hw3-p1/mock-mlee168-mlo5/mock/src/components/ViewCSV.tsx",
    lineNumber: 14,
    columnNumber: 10
  }, this);
};
_c = ViewCSV;
ViewCSV.defaultProps = {
  hasHeader: true
};
export default ViewCSV;
var _c;
$RefreshReg$(_c, "ViewCSV");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/mason/Desktop/Brown/CS32/hw3-p1/mock-mlee168-mlo5/mock/src/components/ViewCSV.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa0JjO0FBbEJkLE9BQU9BLG9CQUFrQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFPekIsTUFBTUMsVUFBa0NBLENBQUM7QUFBQSxFQUFFQztBQUFBQSxFQUFZQztBQUFVLE1BQU07QUFDckUsTUFBSSxDQUFDRDtBQUFZLFdBQU87QUFFeEIsUUFBTUUsYUFBYUQsWUFBWSxJQUFJO0FBRW5DLFNBQ0UsdUJBQUMsV0FDRUE7QUFBQUEsaUJBQ0MsdUJBQUMsV0FDQyxpQ0FBQyxRQUNFRCxxQkFBVyxDQUFDLEVBQUVHLElBQUksQ0FBQ0MsUUFBUUMsVUFDMUIsdUJBQUMsUUFBZ0JELG9CQUFSQyxPQUFUO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBd0IsQ0FDekIsS0FISDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBSUEsS0FMRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBTUE7QUFBQSxJQUVGLHVCQUFDLFdBQ0VMLHFCQUFXTSxNQUFNSixVQUFVLEVBQUVDLElBQUksQ0FBQ0ksS0FBS0MsYUFDdEMsdUJBQUMsUUFDRUQsY0FBSUosSUFBSSxDQUFDTSxNQUFNQyxjQUNkLHVCQUFDLFFBQW9CRCxrQkFBWkMsV0FBVDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTBCLENBQzNCLEtBSE1GLFVBQVQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUlBLENBQ0QsS0FQSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBUUE7QUFBQSxPQWxCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBbUJBO0FBRUo7QUFBRUcsS0EzQklaO0FBNkJOQSxRQUFRYSxlQUFlO0FBQUEsRUFDckJYLFdBQVc7QUFDYjtBQUVBLGVBQWVGO0FBQVEsSUFBQVk7QUFBQUUsYUFBQUYsSUFBQSIsIm5hbWVzIjpbIlJlYWN0IiwiVmlld0NTViIsImxvYWRlZERhdGEiLCJoYXNIZWFkZXIiLCJzdGFydEluZGV4IiwibWFwIiwiaGVhZGVyIiwiaW5kZXgiLCJzbGljZSIsInJvdyIsInJvd0luZGV4IiwiY2VsbCIsImNlbGxJbmRleCIsIl9jIiwiZGVmYXVsdFByb3BzIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiVmlld0NTVi50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gXCJyZWFjdFwiO1xyXG5cclxuaW50ZXJmYWNlIFZpZXdDU1ZQcm9wcyB7XHJcbiAgbG9hZGVkRGF0YTogc3RyaW5nW11bXSB8IG51bGw7XHJcbiAgaGFzSGVhZGVyOiBib29sZWFuOyAvLyBBZGQgdGhpcyBsaW5lIGZvciB0aGUgbmV3IGJvb2xlYW4gcHJvcFxyXG59XHJcblxyXG5jb25zdCBWaWV3Q1NWOiBSZWFjdC5GQzxWaWV3Q1NWUHJvcHM+ID0gKHsgbG9hZGVkRGF0YSwgaGFzSGVhZGVyIH0pID0+IHtcclxuICBpZiAoIWxvYWRlZERhdGEpIHJldHVybiBudWxsO1xyXG5cclxuICBjb25zdCBzdGFydEluZGV4ID0gaGFzSGVhZGVyID8gMSA6IDA7IC8vIERlY2lkZSB3aGVyZSB0byBzdGFydCByZW5kZXJpbmcgZnJvbSBiYXNlZCBvbiB0aGUgaGFzSGVhZGVyIGZsYWdcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDx0YWJsZT5cclxuICAgICAge2hhc0hlYWRlciAmJiAoXHJcbiAgICAgICAgPHRoZWFkPlxyXG4gICAgICAgICAgPHRyPlxyXG4gICAgICAgICAgICB7bG9hZGVkRGF0YVswXS5tYXAoKGhlYWRlciwgaW5kZXgpID0+IChcclxuICAgICAgICAgICAgICA8dGgga2V5PXtpbmRleH0+e2hlYWRlcn08L3RoPlxyXG4gICAgICAgICAgICApKX1cclxuICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgPC90aGVhZD5cclxuICAgICAgKX1cclxuICAgICAgPHRib2R5PlxyXG4gICAgICAgIHtsb2FkZWREYXRhLnNsaWNlKHN0YXJ0SW5kZXgpLm1hcCgocm93LCByb3dJbmRleCkgPT4gKFxyXG4gICAgICAgICAgPHRyIGtleT17cm93SW5kZXh9PlxyXG4gICAgICAgICAgICB7cm93Lm1hcCgoY2VsbCwgY2VsbEluZGV4KSA9PiAoXHJcbiAgICAgICAgICAgICAgPHRkIGtleT17Y2VsbEluZGV4fT57Y2VsbH08L3RkPlxyXG4gICAgICAgICAgICApKX1cclxuICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgKSl9XHJcbiAgICAgIDwvdGJvZHk+XHJcbiAgICA8L3RhYmxlPlxyXG4gICk7XHJcbn07XHJcblxyXG5WaWV3Q1NWLmRlZmF1bHRQcm9wcyA9IHtcclxuICBoYXNIZWFkZXI6IHRydWUsXHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBWaWV3Q1NWO1xyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL21hc29uL0Rlc2t0b3AvQnJvd24vQ1MzMi9odzMtcDEvbW9jay1tbGVlMTY4LW1sbzUvbW9jay9zcmMvY29tcG9uZW50cy9WaWV3Q1NWLnRzeCJ9