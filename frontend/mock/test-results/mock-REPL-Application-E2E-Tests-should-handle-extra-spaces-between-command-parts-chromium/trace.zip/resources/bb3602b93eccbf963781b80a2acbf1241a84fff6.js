import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/SearchCSV.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=577582ce"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/mason/Desktop/Brown/CS32/hw3-p1/mock-mlee168-mlo5/mock/src/components/SearchCSV.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
const SearchCSV = ({
  loadedData
}) => {
  const defaultValue = "Default Search Value";
  if (!loadedData) {
    return /* @__PURE__ */ jsxDEV("span", { children: "No data loaded. Please use load_file before searching." }, void 0, false, {
      fileName: "C:/Users/mason/Desktop/Brown/CS32/hw3-p1/mock-mlee168-mlo5/mock/src/components/SearchCSV.tsx",
      lineNumber: 14,
      columnNumber: 12
    }, this);
  }
  return /* @__PURE__ */ jsxDEV("span", { children: defaultValue }, void 0, false, {
    fileName: "C:/Users/mason/Desktop/Brown/CS32/hw3-p1/mock-mlee168-mlo5/mock/src/components/SearchCSV.tsx",
    lineNumber: 19,
    columnNumber: 10
  }, this);
};
_c = SearchCSV;
export default SearchCSV;
var _c;
$RefreshReg$(_c, "SearchCSV");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/mason/Desktop/Brown/CS32/hw3-p1/mock-mlee168-mlo5/mock/src/components/SearchCSV.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBWVc7QUFaWCxPQUFPQSxvQkFBa0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBT3pCLE1BQU1DLFlBQXNDQSxDQUFDO0FBQUEsRUFBRUM7QUFBVyxNQUFNO0FBRTlELFFBQU1DLGVBQWU7QUFFckIsTUFBSSxDQUFDRCxZQUFZO0FBQ2YsV0FBTyx1QkFBQyxVQUFLLHNFQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBNEQ7QUFBQSxFQUNyRTtBQUlBLFNBQU8sdUJBQUMsVUFBTUMsMEJBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFvQjtBQUM3QjtBQUFFQyxLQVhJSDtBQWFOLGVBQWVBO0FBQVUsSUFBQUc7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIlJlYWN0IiwiU2VhcmNoQ1NWIiwibG9hZGVkRGF0YSIsImRlZmF1bHRWYWx1ZSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiU2VhcmNoQ1NWLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IFNlYXJjaENTVlByb3BzIH0gZnJvbSBcIi4vdHlwZXNcIjtcclxuXHJcbi8qKlxyXG4gKiBTZWFyY2hDU1YgY29tcG9uZW50IGhhbmRsZXMgc2VhcmNoaW5nIGRhdGEgbG9hZGVkIGluIHRoZSBSRVBMLlxyXG4gKiBAcGFyYW0gbG9hZGVkRGF0YSAtIFRoZSBsb2FkZWQgZGF0YSB0byBzZWFyY2ggd2l0aGluLlxyXG4gKi9cclxuY29uc3QgU2VhcmNoQ1NWOiBSZWFjdC5GQzxTZWFyY2hDU1ZQcm9wcz4gPSAoeyBsb2FkZWREYXRhIH0pID0+IHtcclxuICAvLyBGb3Igbm93LCByZXR1cm5pbmcgYSBkZWZhdWx0IHZhbHVlXHJcbiAgY29uc3QgZGVmYXVsdFZhbHVlID0gXCJEZWZhdWx0IFNlYXJjaCBWYWx1ZVwiO1xyXG5cclxuICBpZiAoIWxvYWRlZERhdGEpIHtcclxuICAgIHJldHVybiA8c3Bhbj5ObyBkYXRhIGxvYWRlZC4gUGxlYXNlIHVzZSBsb2FkX2ZpbGUgYmVmb3JlIHNlYXJjaGluZy48L3NwYW4+O1xyXG4gIH1cclxuXHJcbiAgLy8gSGVyZSwgeW91IHdvdWxkIG5vcm1hbGx5IGltcGxlbWVudCB5b3VyIHNlYXJjaCBsb2dpY1xyXG4gIC8vIEZvciBub3csIHJldHVybmluZyB0aGUgZGVmYXVsdCB2YWx1ZVxyXG4gIHJldHVybiA8c3Bhbj57ZGVmYXVsdFZhbHVlfTwvc3Bhbj47XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBTZWFyY2hDU1Y7XHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvbWFzb24vRGVza3RvcC9Ccm93bi9DUzMyL2h3My1wMS9tb2NrLW1sZWUxNjgtbWxvNS9tb2NrL3NyYy9jb21wb25lbnRzL1NlYXJjaENTVi50c3gifQ==