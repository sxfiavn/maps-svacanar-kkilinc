import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/REPL.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=577582ce"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/mason/Desktop/Brown/CS32/hw3-p1/mock-mlee168-mlo5/mock/src/components/REPL.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=577582ce"; const useState = __vite__cjsImport3_react["useState"];
import "/src/styles/main.css";
import { REPLHistory } from "/src/components/REPLHistory.tsx";
import { REPLInput } from "/src/components/REPLInput.tsx";
import { OnStartUp } from "/src/components/FileLoader.tsx";
export default function REPL() {
  _s();
  const [commandHistory, setCommandHistory] = useState([{
    command: "Welcome Message:",
    result: /* @__PURE__ */ jsxDEV(OnStartUp, {}, void 0, false, {
      fileName: "C:/Users/mason/Desktop/Brown/CS32/hw3-p1/mock-mlee168-mlo5/mock/src/components/REPL.tsx",
      lineNumber: 15,
      columnNumber: 13
    }, this)
  }]);
  const [mode, setMode] = useState("brief");
  const [loadedData, setLoadedData] = useState(null);
  const handleDataLoad = (data) => {
    setLoadedData(data);
  };
  const handleChangeMode = (newMode) => {
    setMode(newMode);
  };
  const handleCommandSubmit = (command) => {
    if (command) {
      setCommandHistory((prevHistory) => [...prevHistory, command]);
    } else {
      console.error("Invalid command");
    }
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "repl", children: [
    /* @__PURE__ */ jsxDEV(REPLHistory, { history: commandHistory, mode }, void 0, false, {
      fileName: "C:/Users/mason/Desktop/Brown/CS32/hw3-p1/mock-mlee168-mlo5/mock/src/components/REPL.tsx",
      lineNumber: 35,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("hr", {}, void 0, false, {
      fileName: "C:/Users/mason/Desktop/Brown/CS32/hw3-p1/mock-mlee168-mlo5/mock/src/components/REPL.tsx",
      lineNumber: 36,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      REPLInput,
      {
        onModeChange: handleChangeMode,
        onCommandSubmit: handleCommandSubmit,
        onDataLoad: handleDataLoad,
        loadedData
      },
      void 0,
      false,
      {
        fileName: "C:/Users/mason/Desktop/Brown/CS32/hw3-p1/mock-mlee168-mlo5/mock/src/components/REPL.tsx",
        lineNumber: 37,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/mason/Desktop/Brown/CS32/hw3-p1/mock-mlee168-mlo5/mock/src/components/REPL.tsx",
    lineNumber: 34,
    columnNumber: 10
  }, this);
}
_s(REPL, "YsA70g23OmADChjnBMN8J8b8QTQ=");
_c = REPL;
var _c;
$RefreshReg$(_c, "REPL");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/mason/Desktop/Brown/CS32/hw3-p1/mock-mlee168-mlo5/mock/src/components/REPL.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBYWM7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBYmQsU0FBU0EsZ0JBQWdCO0FBQ3pCLE9BQU87QUFDUCxTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0MsaUJBQWlCO0FBRTFCLFNBQTZCQyxpQkFBaUI7QUFJOUMsd0JBQXdCQyxPQUFPO0FBQUFDLEtBQUE7QUFDN0IsUUFBTSxDQUFDQyxnQkFBZ0JDLGlCQUFpQixJQUFJUCxTQUF3QixDQUNsRTtBQUFBLElBQ0VRLFNBQVM7QUFBQSxJQUNUQyxRQUFRLHVCQUFDLGVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFVO0FBQUEsRUFDcEIsQ0FBQyxDQUNGO0FBQ0QsUUFBTSxDQUFDQyxNQUFNQyxPQUFPLElBQUlYLFNBQWlCLE9BQU87QUFDaEQsUUFBTSxDQUFDWSxZQUFZQyxhQUFhLElBQUliLFNBQTRCLElBQUk7QUFFcEUsUUFBTWMsaUJBQWlCQSxDQUFDQyxTQUFxQjtBQUUzQ0Ysa0JBQWNFLElBQUk7QUFBQSxFQUNwQjtBQUVBLFFBQU1DLG1CQUFtQkEsQ0FBQ0MsWUFBb0I7QUFDNUNOLFlBQVFNLE9BQU87QUFBQSxFQUNqQjtBQUVBLFFBQU1DLHNCQUFzQkEsQ0FBQ1YsWUFBeUI7QUFDcEQsUUFBSUEsU0FBUztBQUNYRCx3QkFBbUJZLGlCQUFnQixDQUFDLEdBQUdBLGFBQWFYLE9BQU8sQ0FBQztBQUFBLElBQzlELE9BQU87QUFDTFksY0FBUUMsTUFBTSxpQkFBaUI7QUFBQSxJQUNqQztBQUFBLEVBQ0Y7QUFFQSxTQUNFLHVCQUFDLFNBQUksV0FBVSxRQUNiO0FBQUEsMkJBQUMsZUFBWSxTQUFTZixnQkFBZ0IsUUFBdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFpRDtBQUFBLElBQ2pELHVCQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFJO0FBQUEsSUFDSjtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsY0FBY1U7QUFBQUEsUUFDZCxpQkFBaUJFO0FBQUFBLFFBQ2pCLFlBQVlKO0FBQUFBLFFBQ1o7QUFBQTtBQUFBLE1BSkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBSTBCO0FBQUEsT0FQNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQVNBO0FBRUo7QUFBQ1QsR0F2Q3VCRCxNQUFJO0FBQUFrQixLQUFKbEI7QUFBSSxJQUFBa0I7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwiUkVQTEhpc3RvcnkiLCJSRVBMSW5wdXQiLCJPblN0YXJ0VXAiLCJSRVBMIiwiX3MiLCJjb21tYW5kSGlzdG9yeSIsInNldENvbW1hbmRIaXN0b3J5IiwiY29tbWFuZCIsInJlc3VsdCIsIm1vZGUiLCJzZXRNb2RlIiwibG9hZGVkRGF0YSIsInNldExvYWRlZERhdGEiLCJoYW5kbGVEYXRhTG9hZCIsImRhdGEiLCJoYW5kbGVDaGFuZ2VNb2RlIiwibmV3TW9kZSIsImhhbmRsZUNvbW1hbmRTdWJtaXQiLCJwcmV2SGlzdG9yeSIsImNvbnNvbGUiLCJlcnJvciIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiUkVQTC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IFwiLi4vc3R5bGVzL21haW4uY3NzXCI7XHJcbmltcG9ydCB7IFJFUExIaXN0b3J5IH0gZnJvbSBcIi4vUkVQTEhpc3RvcnlcIjtcclxuaW1wb3J0IHsgUkVQTElucHV0IH0gZnJvbSBcIi4vUkVQTElucHV0XCI7XHJcbmltcG9ydCB7IElucHV0T2JqZWN0IH0gZnJvbSBcIi4vdHlwZXNcIjtcclxuaW1wb3J0IHsgQXZhaWxhYmxlRmlsZXNMaXN0LCBPblN0YXJ0VXAgfSBmcm9tIFwiLi9GaWxlTG9hZGVyXCI7XHJcbi8qKlxyXG4gKiBSRVBMIGNvbXBvbmVudCBhY3RzIGFzIHRoZSBtYWluIGNvbnRhaW5lciBmb3IgdGhlIFJlYWQtRXZhbC1QcmludCBMb29wIChSRVBMKSBhcHBsaWNhdGlvbi5cclxuICovXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFJFUEwoKSB7XHJcbiAgY29uc3QgW2NvbW1hbmRIaXN0b3J5LCBzZXRDb21tYW5kSGlzdG9yeV0gPSB1c2VTdGF0ZTxJbnB1dE9iamVjdFtdPihbXHJcbiAgICB7XHJcbiAgICAgIGNvbW1hbmQ6IFwiV2VsY29tZSBNZXNzYWdlOlwiLFxyXG4gICAgICByZXN1bHQ6IDxPblN0YXJ0VXAgLz4sXHJcbiAgICB9LFxyXG4gIF0pO1xyXG4gIGNvbnN0IFttb2RlLCBzZXRNb2RlXSA9IHVzZVN0YXRlPHN0cmluZz4oXCJicmllZlwiKTtcclxuICBjb25zdCBbbG9hZGVkRGF0YSwgc2V0TG9hZGVkRGF0YV0gPSB1c2VTdGF0ZTxzdHJpbmdbXVtdIHwgbnVsbD4obnVsbCk7IC8vIE5FVzogc3RhdGUgdG8gc3RvcmUgbG9hZGVkIGRhdGFcclxuXHJcbiAgY29uc3QgaGFuZGxlRGF0YUxvYWQgPSAoZGF0YTogc3RyaW5nW11bXSkgPT4ge1xyXG4gICAgLy8gTkVXOiBoYW5kbGVyIGZvciBsb2FkZWQgZGF0YVxyXG4gICAgc2V0TG9hZGVkRGF0YShkYXRhKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVDaGFuZ2VNb2RlID0gKG5ld01vZGU6IHN0cmluZykgPT4ge1xyXG4gICAgc2V0TW9kZShuZXdNb2RlKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVDb21tYW5kU3VibWl0ID0gKGNvbW1hbmQ6IElucHV0T2JqZWN0KSA9PiB7XHJcbiAgICBpZiAoY29tbWFuZCkge1xyXG4gICAgICBzZXRDb21tYW5kSGlzdG9yeSgocHJldkhpc3RvcnkpID0+IFsuLi5wcmV2SGlzdG9yeSwgY29tbWFuZF0pO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkludmFsaWQgY29tbWFuZFwiKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJyZXBsXCI+XHJcbiAgICAgIDxSRVBMSGlzdG9yeSBoaXN0b3J5PXtjb21tYW5kSGlzdG9yeX0gbW9kZT17bW9kZX0gLz5cclxuICAgICAgPGhyPjwvaHI+XHJcbiAgICAgIDxSRVBMSW5wdXRcclxuICAgICAgICBvbk1vZGVDaGFuZ2U9e2hhbmRsZUNoYW5nZU1vZGV9XHJcbiAgICAgICAgb25Db21tYW5kU3VibWl0PXtoYW5kbGVDb21tYW5kU3VibWl0fVxyXG4gICAgICAgIG9uRGF0YUxvYWQ9e2hhbmRsZURhdGFMb2FkfVxyXG4gICAgICAgIGxvYWRlZERhdGE9e2xvYWRlZERhdGF9IC8vIE5FVzogcGFzc2luZyBsb2FkZWQgZGF0YSBkb3duIHRvIFJFUExJbnB1dFxyXG4gICAgICAvPlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufVxyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL21hc29uL0Rlc2t0b3AvQnJvd24vQ1MzMi9odzMtcDEvbW9jay1tbGVlMTY4LW1sbzUvbW9jay9zcmMvY29tcG9uZW50cy9SRVBMLnRzeCJ9