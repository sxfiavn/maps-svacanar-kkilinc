

export const ACCESS_TOKEN =
  "pk.eyJ1IjoiYW1hbmRhaHNhbmRhdGUiLCJhIjoiY2xvbDZhNWg1MGdxZjJscW4wend5bWhtaiJ9.dgDSL8TfrAMLQwdFUlXtUw";