// MapBox.tsx
import React, { useEffect, useState, useRef, useContext } from "react";
import Map, { Layer, Source, MapRef, MapLayerMouseEvent } from "react-map-gl";

import { WebMercatorViewport } from "viewport-mercator-project";

import bbox from "@turf/bbox";
import { FeatureCollection } from "geojson";
import { GeoJSONContext } from "./GeoJSONContext";
import { highlightLayerStyle, geoLayer, overlayData } from "./overlays";
import { ACCESS_TOKEN } from "./private/api";
import "./styles/index.css";
import * as mapboxgl from "mapbox-gl";

interface LatLong {
  lat: number;
  long: number;
}

interface PopupInfo {
  area_description_data?: string;
  city?: string;
  holc_grade?: string;
  holc_id?: string;
  neighborhood_id?: string;
  state?: string;
  latitude: number;
  longitude: number;
}

function isFeatureCollectionV1(json: any): json is FeatureCollection {
  const result = json.type === "FeatureCollection";
  if (!result) {
    console.log(
      "isFeatureCollectionV1: Input JSON is not a FeatureCollection:",
      json
    );
  }
  return result;
}

export function overlayDataV1(
  data: any
): GeoJSON.FeatureCollection | undefined {
  if (isFeatureCollectionV1(data)) {
    console.log(
      "overlayDataV1: Input data is a FeatureCollection, returning data:",
      data
    );
    return data;
  } else {
    console.log("overlayDataV1: Input data is not a FeatureCollection:", data);
    return undefined;
  }
}

// Utility function to calculate bounds
function getBoundsOfFeature(feature) {
  const bounds = new mapboxgl.LngLatBounds();

  feature.geometry.coordinates.forEach((polygon) => {
    polygon.forEach((coordinate) => {
      bounds.extend(coordinate);
    });
  });

  return bounds;
}

function MapBox() {
  const ProvidenceLatLong: LatLong = { lat: 41.824, long: -71.4128 };
  const initialZoom = 10;
  const mapRef = useRef<MapRef>(null);
  const [popupInfo, setPopupInfo] = useState<PopupInfo | null>(null);

  const [viewState, setViewState] = useState({
    longitude: ProvidenceLatLong.long,
    latitude: ProvidenceLatLong.lat,
    zoom: initialZoom,
  });

  const [overlay, setOverlay] = useState<GeoJSON.FeatureCollection | undefined>(
    undefined
  );

  const context = useContext(GeoJSONContext);
  const geoJSON = context?.geoJSON; // Use optional chaining here

  // You can use the overlayData for your initial data or as fallback
  // Log when the component renders and when the geoJSON context changes
  useEffect(() => {
    console.log("MapBox component has rendered");
    // If you want to check whether the overlay is actually set
    if (overlay) {
      console.log("Current overlay set in state:", overlay);
    }
  });

  // useEffect(() => {
  //   if (geoJSON) {
  //     console.log("Highlighting regions with geoJSON:", geoJSON);
  //     // Add additional logging or checks here if needed
  //   }
  // }, [geoJSON]);

  // When geoJSON is updated, fit the map bounds to its features
  useEffect(() => {
    if (
      geoJSON &&
      isFeatureCollectionV1(geoJSON) &&
      geoJSON.features.length > 0
    ) {
      // Assuming the geometry type is either Point or MultiPolygon
      const bounds = getBoundsOfFeature(geoJSON.features[0]);

      // Log the calculated bounds
      console.log("Calculated bounds:", bounds);

      // Update the viewState with the center of the bounds and an appropriate zoom level
      setViewState((prevState) => ({
        ...prevState,
        longitude: bounds.getCenter().lng,
        latitude: bounds.getCenter().lat,
        // You may need to adjust the zoom level depending on your requirements
        zoom: 10,
      }));

      // Log the updated viewState
      console.log("Updated viewState:", {
        longitude: bounds.getCenter().lng,
        latitude: bounds.getCenter().lat,
        zoom: 10,
      });
    }
  }, [geoJSON, setViewState]); // a

  function onMapClick(e: MapLayerMouseEvent) {
    if (mapRef.current) {
      const bbox: [[number, number], [number, number]] = [
        [e.point.x - 5, e.point.y - 5],
        [e.point.x + 5, e.point.y + 5],
      ];

      const features = mapRef.current.queryRenderedFeatures(bbox, {
        layers: ["geo_data"],
      });

      if (features.length > 0) {
        const feature = features[0];
        const properties = feature.properties as PopupInfo | undefined;
        if (properties) {
          setPopupInfo({
            ...properties,
            latitude: e.lngLat.lat,
            longitude: e.lngLat.lng,
          });
        }
      }
    }
  }
  const closeInfoBox = () => {
    setPopupInfo(null);
  };

  return (
    <div className="MapBox">
      <Map
        mapboxAccessToken={ACCESS_TOKEN}
        {...viewState}
        onMove={(ev) => setViewState(ev.viewState)}
        style={{ width: "100%", height: "100%" }}
        mapStyle="mapbox://styles/mapbox/streets-v12"
        onClick={onMapClick}
        ref={mapRef}
      >
        {/* Base map overlay */}
        <Source id="red_line_data" type="geojson" data={overlayData()}>
          <Layer {...geoLayer} />
        </Source>

        {/* Highlighted regions layer (styling is good) */}
        {geoJSON && (
          <Source
            id="highlighted_geo_data"
            type="geojson"
            data={overlayDataV1(geoJSON)}
          >
            {/* The highlightLayerStyle will be rendered on top of red_line_data by default */}
            <Layer {...highlightLayerStyle} />
          </Source>
        )}

        {popupInfo && (
          <div className="infoBox">
            <div>
              <strong>Area:</strong> {popupInfo.area_description_data}
            </div>
            <div>
              <strong>City:</strong> {popupInfo.city}
            </div>
            <div>
              <strong>State:</strong> {popupInfo.state}
            </div>
            <div>
              <strong>HOLC Gracde:</strong> {popupInfo.holc_grade}
            </div>
            <div>
              <strong>Neighbourhood ID:</strong> {popupInfo.neighborhood_id}
            </div>
            <div>
              <strong>Latitude/Longitude:</strong>{" "}
              {popupInfo.latitude.toFixed(4)}
              {"/"}
              {popupInfo.longitude.toFixed(4)}
            </div>

            <button className="closing" onClick={closeInfoBox}>
              Close
            </button>
          </div>
        )}
      </Map>
    </div>
  );
}

export default MapBox;
