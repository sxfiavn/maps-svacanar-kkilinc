import { test, expect, Page } from "@playwright/test";
import * as path from "path";
import * as fs from "fs";


test.describe("REPL Application Tests", () => {
    let page: Page;
  
test.beforeEach(async ({ browser }) => {
    page = await browser.newPage();
    await page.goto("http://localhost:8000");
});

test.afterEach(async () => {
    await page.close();
});



test.describe("MapBox Integration Tests", () => {
  test("should display the area from mocked GeoJSON when search is performed", async ({
    page,
  }) => {
    // Path to the mocked GeoJSON data file
    const mockDataPath = path.join(
      __dirname,
      "data",
      "mock",
      "mockGeoJSON.json"
    );
    const mockData = fs.readFileSync(mockDataPath, "utf-8");

    // Intercept the searchArea API request and respond with mocked data
    await page.route("**/searchArea**", (route) =>
      route.fulfill({
        status: 200,
        contentType: "application/json",
        body: mockData,
      })
    );

    // Go to your application's page
    // await page.goto("http://localhost:8000");
    await page.fill(".repl-command-box", "search_area providence");
    await page.click("button");


    
    // Assert that the map has been updated with the mocked data
    // This could involve checking for certain text, visibility of map markers, etc.
    // const areaDescription = await page.innerText('.infoBox');
    // expect(areaDescription).toContain('Providence');

    // Add more assertions as needed based on the behavior of your application
  });
});
